const express=require('express')
const router=express.Router()
const customerController=require('./Customer/customerController')
const florist=require('./Florist/floristController')
const gds=require('./GD/gdController')
const guide=require('./Guide/guideController')
const plant=require('./Plants/plantController')
const florisDesigns=require('./Florist/floristDesignController')
const gdDesigns=require('./GD/designController')
const wishlist=require('./Plants/wishlistController')
const orders=require('./Plants/plantOrderController')
const flApp=require('./Appointments/floristappointMentController')
const gdApp=require('./Appointments/gdAppointmentController')
const products=require('./products/prodController')

const Chats=require('./Chats/chatController')




//florist  routes
router.post('/registerFlorist',florist.upload,florist.registerFlorist)
router.post('/loginFlorist',florist.loginFlorist)
router.post('/viewFlorists',florist.viewFlorists)
router.post('/editFloristById/:id',florist.upload,florist.editFloristById)
router.post('/viewFloristById/:id',florist.viewFloristById)
router.post('/forgotpwdFlorist',florist.forgotPassword)
router.post('/deleteFlorist/:id',florist.delFloristById)
router.post('/viewFloristReqs',florist.viewFloristReqs)
router.post('/approvefloristById/:id',florist.approvefloristById)


//gd  routes
router.post('/registerGD',gds.upload,gds.registerGD)
router.post('/loginGD',gds.loginGD)
router.post('/viewGDs',gds.viewGDs)
router.post('/editGDById/:id',gds.upload,gds.editGDById)
router.post('/delGDById/:id',gds.delGDById)
router.post('/viewGDById/:id',gds.viewFGDById)
router.post('/forgotpwdGD',gds.forgotPassword)



//GD Designs  routes
router.post('/addGDDesign',gdDesigns.upload,gdDesigns.addDesign)
router.post('/viewAllGDDesigns',gdDesigns.viewAllDesigns)
router.post('/viewDesignByGDid/:id',gdDesigns.viewDesignByGD)
router.post('/editDesignByGDId/:id',gdDesigns.upload,gdDesigns.editDesignById)
router.post('/delDesignByGDId/:id',gdDesigns.delDesignById)



router.post('/viewAppointmentReqsByGd/:id',gds.viewAppointmentReqsByGd)
router.post('/approveRequestByGd/:id',gds.approveRequestByGd)
router.post('/rejectRequestByGd/:id',gds.rejectRequestByGd)

router.post('/requestApponitmentGD',gds.requestApponitmentGD) // create request by cust for garden designer

router.post('/viewGDReqs',gds.viewGDReqs) // admin approve list
router.post('/approveGDById/:id',gds.approveGDById) // admin approve




//guide  routes
// router.post('/registerGuide',guide.registerGuide)
// router.post('/loginGuide',guide.loginGD)
// router.post('/viewGuides',guide.viewGDs)
// router.post('/editGuideById/:id',guide.editGDById)
// router.post('/viewGuideById/:id',guide.viewGuideById)
// router.post('/forgotpwdGuide',guide.forgotPassword)
// router.post('/deleteGuide/:id',guide.delFGDById)


//cust  routes
router.post('/registerCustomer',customerController.registerCustomer)
router.post('/loginCustomer',customerController.loginCustomer)
router.post('/viewCustomers',customerController.viewCustomers)
router.post('/editCustomerById/:id',customerController.editCustomersById)
router.post('/viewCustomerById/:id',customerController.viewCustomerById)
router.post('/forgotpwd',customerController.forgotPassword)
router.post('/delCustomerById/:id',customerController.delCustById)




//plant routes

router.post('/addPlant',plant.upload,plant.addplant)
router.post('/viewAllPlants',plant.viewPlants) // view all plant
router.post('/viewAllPlantsAdmin',plant.viewAllPlants) // view all plant
router.post('/approvePlantById/:id',plant.approvePlantById) // view all plant



router.post('/viewAllPlantsforCustById/:custId',plant.viewPlantsForCustId) // view our plant
router.post('/delPlantById/:id',plant.delPlantById)
router.post('/viewPlantById/:id',plant.viewPlantById)
router.post('/editPlantById/:id',plant.upload,plant.editPlantById)
router.post('/viewPlantOrderById/:id',plant.viewPlantOrderById)

//wishlist  routes
router.post('/addtoWishlist',wishlist.addtoWishlist)
router.post('/viewWishlistById/:id',wishlist.viewWishlistById)
router.post('/viewWishlistyCustomerId/:id',wishlist.viewWishlistyCustomerId)
router.post('/removeWishListById/:id',wishlist.removeWishListById)


//order  routes
router.post('/addtoorders',orders.addtoOrders) // plant order by cust, for cust plants // payment  
router.post('/viewOrderByCustomerId/:id',orders.viewOrderByCustomerId) // view My orders 
router.post('/viewOrderById/:id',orders.viewOrderById)
router.post('/removeOrderById/:id',orders.removeOrderById)
router.post('/viewOrdersForACustomerId/:id',orders.viewOrdersForACustomerId) // view other's orders
router.post('/viewAllOrders',orders.viewAllOrders) // view other's orders





//GD Appointment  routes
router.post('/addAppointmentGD',gdApp.addAppointment)
router.post('/viewPendingAppointnmentsGDByCustomerId/:id',gdApp.viewPendingAppointnmentsByCustomerId)
router.post('/viewAprvdAppointnmentsGDByCustomerId/:id',gdApp.viewAprvdAppointnmentsByCustomerId)
router.post('/removeAppointmentGDById/:id',gdApp.removeAppointmentById)
router.post('/viewPendingAppointnmentsByGD/:id',gdApp.viewPendingAppointnmentsByGD)
router.post('/ConfrimAppointmentBygd/:id',gdApp.ConfrimAppointmentBygd)


//florist Appointment  routes
router.post('/addAppointmentFlorist',flApp.addAppointment)
router.post('/viewPendingFlorAppointnmentsByCustomerId/:id',flApp.viewPendingAppointnmentsByCustomerId)
router.post('/viewAprvdFlorAppointnmentsByCustomerId/:id',flApp.viewAprvdAppointnmentsByCustomerId)
router.post('/removeAppointmentFlorById/:id',flApp.removeAppointmentById)
router.post('/viewPendingAppointnmentsByFlor/:id',flApp.viewPendingAppointnmentsByFlor)
router.post('/ConfrimAppointmentByFlorist/:id',flApp.ConfrimAppointmentByFlorist)


//florisDesigns  routes
router.post('/addDesign',florisDesigns.upload,florisDesigns.addDesign)
router.post('/viewAllDesigns',florisDesigns.viewAllDesigns)
router.post('/viewDesignByFid/:id',florisDesigns.viewDesignByFid)
router.post('/editDesignById/:id',florisDesigns.upload,florisDesigns.editDesignById)
router.post('/delDesignById/:id',florisDesigns.delDesignById)


//product  routes
router.post('/add',products.upload,products.addprdct)
router.post('/viewPrdtById/:id',products.viewPrdtById)
router.post('/editPrdtById/:id',products.upload,products.editPrdtById)
router.post('/delPrdtById/:id',products.delPrdtById)
router.post('/buyProduct',products.buyProduct)
router.post('/viewPdtOrderByCustId/:id',products.viewPdtOrderByCustId)
router.post('/viewPdtOrderByProdId/:id',products.viewPdtOrderByProdId)
router.post('/viewProducts',products.viewProducts)


//chat  routes
router.post('/createChat',Chats.createChat)
router.post('/viewChat',Chats.viewChat)



router.post('/viewChatforCustwithGD/:id',Chats.viewChatforCustwithGD)
router.post('/viewChatforCustwithFlorist/:id',Chats.viewChatforCustwithFlorist)
router.post('/viewChatforCustwithGuide/:id',Chats.viewChatforCustwithGuide)



router.post('/viewChatWithCustwithFloristByIds/:id',Chats.viewChatWithCustwithFloristByIds)
router.post('/viewChatWithCustwithGDByIds/:id',Chats.viewChatWithCustwithGDByIds)




router.post('/viewChatforGD/:id',Chats.viewChatforGD)
router.post('/viewChatforFlorist/:id',Chats.viewChatforFlorist)
router.post('/viewChatforGuide/:id',Chats.viewChatforGuide) 

router.post('/viewChatRecepientsforFlorist/:id',Chats.viewChatRecepientsforFlorist)
router.post('/viewChatRecepientsforGD/:id',Chats.viewChatRecepientsforGD)
router.post('/viewChatRecepientsforGuide',Chats.viewChatRecepientsforGuide)

module.exports=router