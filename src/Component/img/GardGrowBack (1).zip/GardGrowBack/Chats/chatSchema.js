const mongoose= require("mongoose");
    
const Schema=mongoose.Schema({
    cid:{
        type:mongoose.Schema.Types.ObjectId,
        required:true,
        ref:'customers'
    },
    fid:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'florists'
    }, gdid:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'gds'
    },
   from:String,
   to:String,
    date:{
        type:Date
    },
    msg:{
        type:String,
        required:true
    }
});
module.exports=mongoose.model('chats',Schema)
