let chat = require("./chatSchema");

//chat a pgm

const createChat = (req, res) => {
  let date = new Date();
  const newChat = new chat({
    date: date,
    from: req.body.from,
    msg: req.body.msg,
    to: req.body.to,
    cid: req.body.cid,
    fid: req.body.fid,
    gdid: req.body.gdid,
  });
  newChat
    .save()
    .then((data) => {
      res.json({
        status: 200,
        msg: "Inserted successfully",
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Please enter all the mandatory fields",
        Error: err,
      });
    });
};

const viewChat = (req, res) => {
  chat
    .find({})
    .sort({ date: +1 })
    .populate("cid")
    .populate("gdid")
    .exec()
    .then((data) => {
      res.json({
        status: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        err: err,
      });
    });
};
const viewChatforCustwithGuide = (req, res) => {
  chat
    .find({ cid: req.params.id, $or: [{ from: "guide" }, { to: "guide" }] })
    .sort({ date: -1 })
    .exec()
    .then((data) => {
      res.json({
        statu: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        err: err,
      });
    });
};

// view all cust for guide -- test cheythithh
const viewChatforGuide = (req, res) => {
  chat
    .find({ $or: [{ from: "guide" }, { to: "guide" }] })
    .sort({ date: -1 })
    .exec()
    .then((data) => {
      res.json({
        statu: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        err: err,
      });
    });
};
//chat with florists
const viewChatforCustwithFlorist = (req, res) => {
  chat
    .find({ cid: req.params.id, $or: [{ from: "florist" }, { to: "florist" }] })
    .sort({ date: +1 })
    .populate("cid")
    .populate("fid")
    .exec()
    .then((data) => {
      res.json({
        statu: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        err: err,
      });
    });
};
//chat with florists
const viewChatWithCustwithFloristByIds = (req, res) => {
  chat
    .find({ cid: req.body.cid, fid: req.params.id })
    .sort({ date: +1 })
    .populate("fid")
    .populate("cid")
    .exec()
    .then((data) => {
      res.json({
        status: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        err: err,
      });
    });
};


const viewChatWithCustwithGDByIds = (req, res) => {
  chat
    .find({ cid: req.body.cid, gdid: req.params.id })
    .sort({ date: +1 })
    .populate("gdid")
    .populate("cid")
    .exec()
    .then((data) => {
      res.json({
        status: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        err: err,
      });
    });
};
//chat with florists
const viewChatforCustwithGD = (req, res) => {
  chat
    .find({ cid: req.params.id, $or: [{ from: "gd" }, { to: "gd" }] })
    .sort({ date: +1 })
    .populate("cid")
    .populate("gdid")

    .exec()
    .then((data) => {
      res.json({
        statu: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        err: err,
      });
    });
};

//chat for GD with cust
const viewChatforGD = (req, res) => {
  chat
    .find({ gdid: req.params.id })
    .populate("cid")
    .sort({ date: -1 })
    .exec()
    .then((data) => {
      res.json({
        statu: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        err: err,
      });
    });
};

//chat for florists with cust
const viewChatforFlorist = (req, res) => {
  chat
    .find({ fid: req.params.id })
    .populate("cid")
    .sort({ date: +1 })
    .exec()
    .then((data) => {
      res.json({
        statu: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        err: err,
      });
    });
};

const viewChatRecepientsforFlorist = (req, res) => {
  chat
    .find({ fid: req.params.id })
    .populate("cid")
    .distinct("cid")
    .exec()
    .then((data) => {
      res.json({
        statu: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,  
        err: err,
      });
    });
};
const viewChatRecepientsforGD = (req, res) => {
  chat
    .find({ gdid: req.params.id })
    .populate("cid")
    .distinct("cid")
    .exec()
    .then((data) => {
      res.json({
        statu: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        err: err,
      });
    });
};

const viewChatRecepientsforGuide = (req, res) => {
  chat
    .find()
    .populate("cid")
    .distinct("cid")
    .exec()
    .then((data) => {
      res.json({
        statu: 200,
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        err: err,
      });
    });
};

module.exports = {
  createChat,
  viewChatforCustwithGuide,
  viewChatforCustwithFlorist,
  viewChatforCustwithGD,
  viewChatforFlorist,
  viewChatforGD,
  viewChatforGuide,
  viewChat,
  viewChatRecepientsforFlorist,
  viewChatRecepientsforGD,
viewChatRecepientsforGuide,
  viewChatWithCustwithFloristByIds,
  viewChatWithCustwithGDByIds,
};
