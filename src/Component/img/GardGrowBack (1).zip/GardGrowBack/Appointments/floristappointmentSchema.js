const mongoose=require('mongoose')

const cSchema=mongoose.Schema({
        
    userid:{
        type:mongoose.Schema.Types.ObjectId ,
    ref:'customers'
   },
   
  fid: {type:mongoose.Schema.Types.ObjectId ,
   ref:'florists'
  },
    date:{
        type:Date
  
},time:String,
status:{
    tyrpe:Boolean,
    default:false
}

})
 

module.exports=mongoose.model('flappointments',cSchema)