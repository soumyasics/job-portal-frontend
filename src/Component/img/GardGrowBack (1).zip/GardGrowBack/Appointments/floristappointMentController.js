const appSchema = require("./floristappointmentSchema");

const addAppointment = async (req, res) => {
  date = new Date();

  const obj = new appSchema({
    fid: req.body.fid,
    userid: req.body.userid,
  });
  obj.save((err, data) => {
    if (err) {
      res.json({
        status: 500,
        err: err,
        message: err.message,
      });
    } else {
      res.json({
        status: 200,
        data: data,
        message: "Successfully saved",
      });
    }
  });
};

// view order by id
const ConfrimAppointmentByFlorist = (req, res) => {
    const date = new Date()

    if (date.getDate() < new Date(req.body.date)) {
    appSchema
      .findByIdAndUpdate(
        { _id: req.params.id },
        {
          date: req.body.date,
          time: req.body.time,
          isactive: true,
        }
      )
      .exec()
      .then((data) => {
        console.log(data);
        res.json({
          status: 200,
          msg: "Data updated successfully",
        });
      })
      .catch((err) => {
        console.log(err);
        res.json({
          status: 500,
          msg: "No Data obtained",
          Error: err,
        });
      });
  } else {
    res.json({
      status: 500,
      msg: "Please choose Correct Date",
    });
  }
};

// view pending appoint  by custid
const viewPendingAppointnmentsByCustomerId = (req, res) => {
  appSchema
    .find({ userid: req.params.id, isactive: false })
    .populate("fid")
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

//view Approved appointments

const viewAprvdAppointnmentsByCustomerId = (req, res) => {
  appSchema
    .find({ userid: req.params.id, isactive: true })
    .populate("fid")
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

// remove wishlist  by id
const removeAppointmentById = (req, res) => {
  appSchema
    .findByIdAndDelete({ _id: req.params.id })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data removed successfully",
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

// view pending appoint  by request by fl
const viewPendingAppointnmentsByFlor = (req, res) => {
  appSchema
    .find({ fid: req.params.id, isactive: false })
    .populate("userid")
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

module.exports = {
  addAppointment,
  viewAprvdAppointnmentsByCustomerId,
  viewPendingAppointnmentsByCustomerId,
  removeAppointmentById,
  viewPendingAppointnmentsByFlor,
  ConfrimAppointmentByFlorist,
};
