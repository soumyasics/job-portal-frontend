const mongoose = require("mongoose");

const cSchema = mongoose.Schema({
  userid: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "customers",
  },

  gdid: { type: mongoose.Schema.Types.ObjectId, ref: "gds" },
  date: {
    type: Date,
  },
  time: String,
});

module.exports = mongoose.model("gdappointments", cSchema);
