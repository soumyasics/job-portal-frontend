
const designSchema = require('./floristDesignSchema');
const multer=require('multer')
// const cart = require('../user/cart_model')



    const storage=multer.diskStorage({
       destination:function(req,res,cb){
           cb(null,'./upload')
       },
       filename:function(req,file,cb){
           cb(null,file.originalname)
       }
    })

    const upload=multer({storage:storage}).single('image')

const addDesign=(req,res)=>{
    let date=new Date()
    const newGD=new designSchema
    ({
       title:req.body.title,
       type:req.body.type,
       image:req.file,
       fid:req.body.fid,
       cost:req.body.cost,
       date:date
    })
    newGD.save().then(data=>{
        res.json({
            status:200,
            msg:"Inserted successfully",
            data:data
        })
    }).catch(err=>{
        res.json({
            status:500,
            msg:"Data not Inserted",
            Error:err
        })
    })
}


//View all 

const viewDesignByFid=(req,res)=>{
    designSchema.find({fid:req.params.id}).exec()
  .then(data=>{
    if(data.length>0){
    res.json({
        status:200,
        msg:"Data obtained successfully",
        data:data
    })
  }else{
    res.json({
      status:200,
      msg:"No Data obtained "
  })
  }
}).catch(err=>{
    res.json({
        status:500,
        msg:"Data not Inserted",
        Error:err
    })
})

}

// view  finished


//update  by id
const editDesignById=(req,res)=>{

  
    
    designSchema.findByIdAndUpdate({_id:req.params.id},{
    title:req.body.title,
    type:req.body.type,
    image:req.file,
    fid:req.body.fid,
    cost:req.body.cost
    
    })
.exec().then(data=>{
  res.json({
      status:200,
      msg:"Updated successfully"
  })
}).catch(err=>{
  res.json({
      status:500,
      msg:"Data not Updated",
      Error:err
  })
})
}


//View  Cust by ID

const viewDesignById=(req,res)=>{
    designSchema.findOne({_id:req.params.id}).populate('fid').exec()
  .then(data=>{

    console.log(data);
    res.json({
        status:200,
        msg:"Data obtained successfully",
        data:data
    })
  
}).catch(err=>{
  console.log(err);
    res.json({
        status:500,
        msg:"No Data obtained",
        Error:err
    })
})

}


//view allsdesigns

//View  Cust by ID

const viewAllDesigns=(req,res)=>{
    designSchema.find({}).populate('fid').exec()
    .then(data=>{
  
      console.log(data);
      res.json({
          status:200,
          msg:"Data obtained successfully",
          data:data
      })
    
  }).catch(err=>{
    console.log(err);
      res.json({
          status:500,
          msg:"No Data obtained",
          Error:err
      })
  })
  
  }



//View  Cust by ID

const delDesignById=(req,res)=>{
    designSchema.findByIdAndDelete({_id:req.params.id}).exec()
    .then(data=>{
  
      console.log(data);
      res.json({
          status:200,
          msg:"Data obtained successfully",
          data:data
      })
    
  }).catch(err=>{
    console.log(err);
      res.json({
          status:500,
          msg:"No Data obtained",
          Error:err
      })
  })
  
  }



module.exports={addDesign,viewDesignByFid,viewDesignById,viewAllDesigns,editDesignById,upload,delDesignById}

















