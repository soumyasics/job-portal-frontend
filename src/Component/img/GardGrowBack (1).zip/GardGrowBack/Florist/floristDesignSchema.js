
const mongoose= require("mongoose");

const Schema=mongoose.Schema({
   title:{
        type:String,
        required:true
    },
 
   
    type:{
        type:String,
        required:true
    },
  
    image:{
        type:Object
        
    },
   
   fid:{
type:mongoose.Schema.Types.ObjectId,
ref:'florists'
   },
  
       cost:{
        type:Number,
        required:true
       },
       feedback:{
        type:Array
       }
})
        
module.exports=mongoose.model('floristdesigns',Schema)

