const florist = require("./floristSchema");

const multer = require("multer");
// const cart = require('../user/cart_model')

const storage = multer.diskStorage({
  destination: function (req, res, cb) {
    cb(null, "./upload");
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});

const upload = multer({ storage: storage }).single("image");

//Customer Registration

const registerFlorist = (req, res) => {
  const newFlorist = new florist({
    name: req.body.name,
    city: req.body.city,
    image: req.file,
    contact: req.body.contact,
    email: req.body.email,
    password: req.body.password,
  });
  newFlorist
    .save()
    .then((data) => {
      res.json({
        status: 200,
        msg: "Inserted successfully",
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Inserted",
        Error: err,
      });
    });
};
//Florist Registration -- finished

//Login Florist
const loginFlorist = (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  florist
    .findOne({ email: email })
    .exec()
    .then((data) => {
      if (password == data.password) {
        res.json({
          status: 200,
          msg: "Login successfully",
          data: data,
        });
      } else {
        res.json({
          status: 500,
          msg: "password Mismatch",
        });
      }
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "User not found",
        Error: err,
      });
    });
};

//Login Florist --finished

//View all Florists

const viewFlorists = (req, res) => {
  florist
    .find({ isactive: true })
    .exec()
    .then((data) => {
      if (data.length > 0) {
        res.json({
          status: 200,
          msg: "Data obtained successfully",
          data: data,
        });
      } else {
        res.json({
          status: 200,
          msg: "No Data obtained ",
        });
      }
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Inserted",
        Error: err,
      });
    });
};

// view Florists finished

//update Florists by id
const editFloristById = (req, res) => {
  florist
    .findByIdAndUpdate(
      { _id: req.params.id },
      {
        name: req.body.name,
        city: req.body.age,
        image: req.file,
        contact: req.body.contact,
        email: req.body.email,
      }
    )
    .exec()
    .then((data) => {
      res.json({
        status: 200,
        msg: "Updated successfully",
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Updated",
        Error: err,
      });
    });
};

//Florist forgot password
const forgotPassword = (req, res) => {
  florist
    .findOne({ email: req.body.email })
    .exec()

    .then((data) => {
      console.log(data);
      if (data == null) {
        res.json({
          status: 500,
          msg: "User not Found",
        });
      } else {
        florist
          .findOneAndUpdate(
            { email: req.body.email },
            {
              password: req.body.password,
            }
          )
          .exec()
          .then((data) => {
            res.json({
              status: 200,
              msg: "Updated successfully",
            });
          })
          .catch((err) => {
            res.json({
              status: 500,
              msg: "Data not Updated",
              Error: err,
            });
          });
      }
    });
};
//finished -- forgot password
//View  Cust by ID

const viewFloristById = (req, res) => {
  florist
    .findOne({ _id: req.params.id })
    .exec()
    .then((data) => {
      emps = data;
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

const delFloristById = (req, res) => {
  florist
    .findByIdAndDelete({ _id: req.params.id })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};
//Appointments

// add appointment request for gd
const requestApponitmentFlorist = (req, res) => {
  let date = new Date();
  const newGD = new appointmentSchema({
    userid: req.body.userid,
    id: req.body.gdid,
    date: date,
    time: req.body.time,
  });
  newGD
    .save()
    .then((data) => {
      res.json({
        status: 200,
        msg: "Inserted successfully",
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Inserted",
        Error: err,
      });
    });
};

//View  AppointmentReqs by ID

const viewAppointmentReqsByGd = (req, res) => {
  appointmentSchema
    .find({ hdid: req.params.id, status: "pending" })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

//View  Cust by ID

const approveRequestByGd = (req, res) => {
  appointmentSchema
    .findByIdAndUpdate({ _id: req.params.id }, { status: "accepted" })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

//View  Cust by ID

const rejectRequestByGd = (req, res) => {
  appointmentSchema
    .findByIdAndUpdate({ _id: req.params.id }, { status: "rejected" })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

const viewFloristReqs = (req, res) => {
  florist
    .find()
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

//Approve by media

const approvefloristById = (req, res) => {
  florist
    .findByIdAndUpdate({ _id: req.params.id }, { isactive: true })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

module.exports = {
  registerFlorist,
  delFloristById,
  loginFlorist,
  viewFloristById,
  viewFlorists,
  editFloristById,
  forgotPassword,
  viewFloristReqs,
  approvefloristById,
  upload,
};
