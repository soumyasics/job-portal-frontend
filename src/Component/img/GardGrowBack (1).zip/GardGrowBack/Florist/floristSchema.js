const mongoose= require("mongoose");

const Schema=mongoose.Schema({
   name:{
        type:String,
        required:true
    },
 
    city:{
        type:String,
        required:true
    },
    contact:{
        type:Number,
        required:true
    },
  
    email:{
        type:String,
        unique:true,
        required:true,
       
        dropDups: true
    },
    password:{
        type:String,
        required:true
    },
    image:{
        type:Object
    },
    isactive:{
        type:Boolean,
        default:false
    }
})
        
module.exports=mongoose.model('florists',Schema)

