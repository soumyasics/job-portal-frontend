const pdtSchema = require('./prodSchema')
const multer=require('multer')
const orders = require('./pdtOrderSchema')



const storage = multer.diskStorage({
    destination: function (req, res, cb) {
      cb(null, "./upload");
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname);
    },
  });
  
  const upload = multer({ storage: storage }).single("image");
// Registration 

const addprdct=(req,res)=>{
   
    const newPdt=new pdtSchema({
        name:req.body.name,
        cost:req.body.cost,
        type:req.body.type,
        image:req.file
    })
    newPdt.save().then(data=>{
        res.json({
            status:200,
            msg:"Inserted successfully",
            data:data
        })
    }).catch(err=>{
        res.json({
            status:500,
            msg:"Data not Inserted",
            Error:err
        })
    })
}
// Registration -- finished

//View all 

const viewProducts=(req,res)=>{
    pdtSchema.find().exec()
    .then(data=>{
      if(data.length>0){
      res.json({
          status:200,
          msg:"Data obtained successfully",
          data:data
      })
    }else{
      res.json({
        status:200,
        msg:"No Data obtained "
    })
    }
  }).catch(err=>{
      res.json({
          status:500,
          msg:"Data not Inserted",
          Error:err
      })
  })
  
  }
  



const viewPrdtById=(req,res)=>{
    pdtSchema.findOne({_id:req.params.id}).exec()
    .then(data=>{
   
      console.log(data);
      res.json({
          status:200,
          msg:"Data obtained successfully",
          data:data
      })
    
  }).catch(err=>{
    console.log(err);
      res.json({
          status:500,
          msg:"No Data obtained",
          Error:err
      })
  })
  
  }
  
  
// view order for a plant
const viewPdtOrderByProdId=(req,res)=>{
  orders.find({pdtid:req.params.id}).populate('userid').exec()
  .then(data=>{
  
    console.log(data);
    res.json({
        status:200,
        msg:"Data obtained successfully",
        data:data
    })
  
}).catch(err=>{
  console.log(err);
    res.json({
        status:500,
        msg:"No Data obtained",
        Error:err
    })
})

}
  const delPrdtById=(req,res)=>{
    pdtSchema.findByIdAndDelete({_id:req.params.id}).exec()
    .then(data=>{
  
      console.log(data);
      res.json({
          status:200,
          msg:"Data obtained successfully",
          data:data
      })
    
  }).catch(err=>{
    console.log(err);
      res.json({
          status:500,
          msg:"No Data obtained",
          Error:err
      })
  })
  
  }
  //update Plant by id
  const editPrdtById=(req,res)=>{
  
    

    pdtSchema.findByIdAndUpdate({_id:req.params.id},{
        name:req.body.name,
        
        
        type:req.body.type,
       
        cost:req.body.cost,
        guideId:req.body.guideId
      })
  .exec().then(data=>{
    res.json({
        status:200,
        msg:"Updated successfully"
    })
  }).catch(err=>{
    res.json({
        status:500,
        msg:"Data not Updated",
        Error:err
    })
  })
  }
  

  
const buyProduct=(req,res)=>{
   let date=new Date()
    const newPdt=new orders({
        userid:req.body.name,
        date:date,
        price:req.body.price,
        pdtid:req.body.pdtid,
        count:req.body.count
    })
    newPdt.save().then(data=>{
        res.json({
            status:200,
            msg:"Inserted successfully",
            data:data
        })
    }).catch(err=>{
        res.json({
            status:500,
            msg:"Data not Inserted",
            Error:err
        })
    })
}

// view order for a Cust
const viewPdtOrderByCustId=(req,res)=>{
    orders.find({userid:req.params.id}).populate('pdtid').exec()
    .then(data=>{
    
      console.log(data);
      res.json({
          status:200,
          msg:"Data obtained successfully",
          data:data
      })
    
  }).catch(err=>{
    console.log(err);
      res.json({
          status:500,
          msg:"No Data obtained",
          Error:err
      })
  })
}
module.exports={addprdct,delPrdtById,editPrdtById,viewPrdtById,viewProducts,buyProduct,
viewPdtOrderByCustId,viewPdtOrderByProdId,upload}