const mongoose = require("mongoose");

const Schema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },


    type: {
        type: String,
        required: true
    },
    cost: {
        type: Number,
        required: true
    },
    feedback: {
        type: Array
    },
    image: Object
})

module.exports = mongoose.model('products', Schema)

