

const plantSchema = require('../Plants/plantSchema')
const customers=require('./customerSchema')



//Customer Registration 

const registerCustomer=(req,res)=>{
    const newCustomer=new customers({
        name:req.body.name,
        city:req.body.city,
        
        contact:req.body.contact,
        email:req.body.email,
        password:req.body.password
    })
    newCustomer.save().then(data=>{
        res.json({
            status:200,
            msg:"Inserted successfully",
            data:data
        })
    }).catch(err=>{
        res.json({
            status:500,
            msg:"Data not Inserted",
            Error:err
        })
    })
}
//Customer Registration -- finished

//Login Customer 
const loginCustomer=(req,res)=>{
  const email=req.body.email
  const password=req.body.password

  customers.findOne({email:email}).exec().then(data=>{
    if(password==data.password){
      res.json({
        status:200,
        msg:"Login successfully",
        data:data
    })
  }else{
    res.json({
      status:500,
      msg:"password Mismatch",
      
  })
  }
  
}).catch(err=>{
res.json({
    status:500,
    msg:"User not found",
    Error:err
})
})
  };


//Login Customer --finished


//View all Customers

const viewCustomers=(req,res)=>{
  customers.find().exec()
  .then(data=>{
    if(data.length>0){
    res.json({
        status:200,
        msg:"Data obtained successfully",
        data:data
    })
  }else{
    res.json({
      status:200,
      msg:"No Data obtained "
  })
  }
}).catch(err=>{
    res.json({
        status:500,
        msg:"Data not Inserted",
        Error:err
    })
})

}

// view customers finished


//update customers by id
const editCustomersById=(req,res)=>{

  
    
  customers.findByIdAndUpdate({_id:req.params.id},{
    name:req.body.name,
    city:req.body.age,
    
    contact:req.body.contact,
    email:req.body.email
    })
.exec().then(data=>{
  res.json({
      status:200,
      msg:"Updated successfully"
  })
}).catch(err=>{
  res.json({
      status:500,
      msg:"Data not Updated",
      Error:err
  })
})
}


//Customer forgot password
const forgotPassword=(req,res)=>{
  customers.findOne({email:req.body.email}).exec()
  .then(data=>{
    if(data==null){
      res.json({
        status:500,
        msg:"User not Found"
    })
    }
    else{
      customers.findOneAndUpdate({email:req.body.email},{
        password:req.body.password
      }).exec().then(data=>{
        res.json({
          status:200,
          msg:"Updated successfully"
      })
    }).catch(err=>{
      res.json({
          status:500,
          msg:"Data not Updated",
          Error:err
      })
    })
    }
  })
}
//finished -- forgot password
//View  Cust by ID

const viewCustomerById=(req,res)=>{
  customers.findOne({_id:req.params.id}).exec()
  .then(data=>{
  emps=data
    console.log(data);
    res.json({
        status:200,
        msg:"Data obtained successfully",
        data:data
    })
  
}).catch(err=>{
  console.log(err);
    res.json({
        status:500,
        msg:"No Data obtained",
        Error:err
    })
})

}


const delCustById=(req,res)=>{
  customers.findByIdAndDelete({_id:req.params.id}).exec()
  .then(data=>{

    console.log(data);
    res.json({
        status:200,
        msg:"Data obtained successfully",
        data:data
    })
  
}).catch(err=>{
  console.log(err);
    res.json({
        status:500,
        msg:"No Data obtained",
        Error:err
    })
})

}


module.exports={registerCustomer,delCustById,loginCustomer,viewCustomerById,viewCustomers,
  editCustomersById,forgotPassword}