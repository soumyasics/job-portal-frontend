const mongoose= require("mongoose");

const custSchema=mongoose.Schema({
   name:{
        type:String,
        required:true
    },
 
    city:{
        type:String,
        required:true
    },
    contact:{
        type:Number,
        required:true
    },
  
    email:{
        type:String,
        unique:true,
        required:true,
       
        dropDups: true
    },
    password:{
        type:String,
        required:true
    }
})
  
const delCustById=(req,res)=>{
    custSchema.findByIdAndDelete({_id:req.params.id}).exec()
    .then(data=>{
  
      console.log(data);
      res.json({
          status:200,
          msg:"Data obtained successfully",
          data:data
      })
    
  }).catch(err=>{
    console.log(err);
      res.json({
          status:500,
          msg:"No Data obtained",
          Error:err
      })
  })
  
  }
      
module.exports=mongoose.model('customers',custSchema)

