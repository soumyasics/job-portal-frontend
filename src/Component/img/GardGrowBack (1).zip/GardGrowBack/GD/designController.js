

const designSchema = require('./designSchema');
const design=require('./designSchema')
const jwt=require('jsonwebtoken')

const multer=require('multer')
// const cart = require('../user/cart_model')



    const storage=multer.diskStorage({
       destination:function(req,res,cb){
           cb(null,'./upload')
       },
       filename:function(req,file,cb){
           cb(null,file.originalname)
       }
    })

    const upload=multer({storage:storage}).single('image')


// Registration 

const addDesign=(req,res)=>{
    let date=new Date()
    const newGD=new design({
       title:req.body.title,
       type:req.body.type,
       image:req.file,
       gdid:req.body.gdid,
       cost:req.body.cost,
       date:date
    })
    newGD.save().then(data=>{
        res.json({
            status:200,
            msg:"Inserted successfully",
            data:data
        })
    }).catch(err=>{
        res.json({
            status:500,
            msg:"Data not Inserted",
            Error:err
        })
    })
}


//View all 

const viewDesignByGD=(req,res)=>{
  design.find({gdid:req.params.id}).exec()
  .then(data=>{
    if(data.length>0){
    res.json({
        status:200,
        msg:"Data obtained successfully",
        data:data
    })
  }else{
    res.json({
      status:200,
      msg:"No Data obtained ",
      data:data
  })
  }
}).catch(err=>{
    res.json({
        status:500,
        msg:"Data not Inserted",
        Error:err
    })
})

}

// view  finished


//update  by id
const editDesignById=(req,res)=>{

  
    
  design.findByIdAndUpdate({_id:req.params.id},{
    title:req.body.title,
    type:req.body.type,
    image:req.file,
    gdid:req.body.gdid,
    cost:req.body.cost
  
    })
.exec().then(data=>{
  res.json({
      status:200,
      msg:"Updated successfully"
  })
}).catch(err=>{
  res.json({
      status:500,
      msg:"Data not Updated",
      Error:err
  })
})
}


//View  Cust by ID

const viewDesignById=(req,res)=>{
  design.findOne({_id:req.params.id}).exec()
  .then(data=>{

    console.log(data);
    res.json({
        status:200,
        msg:"Data obtained successfully",
        data:data
    })
  
}).catch(err=>{
  console.log(err);
    res.json({
        status:500,
        msg:"No Data obtained",
        Error:err
    })
})

}


//view allsdesigns

//View  Cust by ID

const viewAllDesigns=(req,res)=>{
    design.find({}).exec()
    .then(data=>{
  
      console.log(data);
      res.json({
          status:200,
          msg:"Data obtained successfully",
          data:data
      })
    
  }).catch(err=>{
    console.log(err);
      res.json({
          status:500,
          msg:"No Data obtained",
          Error:err
      })
  })
  
  }



//View  Cust by ID

const delDesignById=(req,res)=>{
    design.findByIdAndDelete({_id:req.params.id}).exec()
    .then(data=>{
  
      console.log(data);
      res.json({
          status:200,
          msg:"Data obtained successfully",
          data:data
      })
    
  }).catch(err=>{
    console.log(err);
      res.json({
          status:500,
          msg:"No Data obtained",
          Error:err
      })
  })
  
  }



module.exports={addDesign,viewDesignByGD,viewDesignById,upload,viewAllDesigns,editDesignById,delDesignById}