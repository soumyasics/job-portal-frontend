// const appointmentSchema = require('./appointmentSchema');
const gd = require("./gdSchema");
const jwt = require("jsonwebtoken");

const secret = "your-secret-key"; // Replace this with your own secret key

const createToken = (user) => {
  return jwt.sign({ userId: user._id }, secret, { expiresIn: "1h" });
};

const multer = require("multer");
const gdAppointmentSchema = require("../Appointments/gdAppointmentSchema");
const storage = multer.diskStorage({
  destination: function (req, res, cb) {
    cb(null, "./upload");
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});

const upload = multer({ storage: storage }).single("image");
// Registration

const registerGD = (req, res) => {
  const newGD = new gd({
    name: req.body.name,
    city: req.body.city,
    image: req.file,
    contact: req.body.contact,
    email: req.body.email,
    password: req.body.password,
  });
  newGD
    .save()
    .then((data) => {
      res.json({
        status: 200,
        msg: "Inserted successfully",
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Inserted",
        Error: err,
      });
    });
};
// Registration -- finished

//Login
const loginGD = (req, res) => {
  const { email, password } = req.body;

  gd.findOne({ email })
    .exec()
    .then((user) => {
      if (!user) {
        return res.status(404).json({ msg: "User not found" });
      }

      if (user.password != password) {
        return res.status(500).json({ msg: "incorrect pwd" });
      }

      const token = createToken(user);

      res.status(200).json({ user, token });
    })
    .catch((err) => {
      console.log(err);
      return res.status(500).json({ msg: "Something went wrong" });
    });
};
//validate

const requireAuth = (req, res, next) => {
  const token = req.headers.authorization.split(" ")[1];

  console.log("t1", token);
  console.log("secret", secret);
  if (!token) {
    return res.status(401).json({ msg: "Unauthorized" });
  }
  jwt.verify(token, secret, (err, decodedToken) => {
    console.log(decodedToken);
    if (err) {
      return res.status(401).json({ messamsgge: "Unauthorized", err: err });
    }

    req.user = decodedToken.userId;
    next();
    return res.status(200).json({ msg: "ok", user: decodedToken.userId });
  });
  console.log(req.user);
};

//Login  --finished

//View all

const viewGDs = (req, res) => {
  gd.find({isactive:true})
    .exec()
    .then((data) => {
      if (data.length > 0) {
        res.json({
          status: 200,
          msg: "Data obtained successfully",
          data: data,
        });
      } else {
        res.json({
          status: 200,
          msg: "No Data obtained ",
        });
      }
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Inserted",
        Error: err,
      });
    });
};

// view  finished

//update  by id
const editGDById = (req, res) => {
  gd.findByIdAndUpdate(
    { _id: req.params.id },
    {
      name: req.body.name,
      city: req.body.city,
      image: req.file,
      contact: req.body.contact,
      email: req.body.email,
    }
  )
    .exec()
    .then((data) => {
      res.json({
        status: 200,
        msg: "Updated successfully",
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Updated",
        Error: err,
      });
    });
};

//Florist forgot password
const forgotPassword = (req, res) => {
  gd.findOne({ email: req.body.email })
    .exec()

    .then((data) => {
      console.log(data);
      if (data == null) {
        res.json({
          status: 500,
          msg: "User not Found",
        });
      } else {
        gd.findOneAndUpdate(
          { email: req.body.email },
          {
            password: req.body.password,
          }
        )
          .exec()
          .then((data) => {
            res.json({
              status: 200,
              msg: "Updated successfully",
            });
          })
          .catch((err) => {
            res.json({
              status: 500,
              msg: "Data not Updated",
              Error: err,
            });
          });
      }
    });
};
//finished -- forgot password
//View  Cust by ID

const viewFGDById = (req, res) => {
  gd.findOne({ _id: req.params.id })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};
//View  Cust by ID

const delGDById = (req, res) => {
  gd.findByIdAndDelete({ _id: req.params.id })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

// add appointment request for gd
const requestApponitmentGD = (req, res) => {
  const newGD = new gdAppointmentSchema({
    userid: req.body.userid,
    gdid: req.body.gdid,
    date: req.body.date,
    time: req.body.time,
  });
  newGD
    .save()
    .then((data) => {
      res.json({
        status: 200,
        msg: "Inserted successfully",
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Inserted",
        Error: err,
      });
    });
};

//View  AppointmentReqs by ID

const viewAppointmentReqsByGd = (req, res) => {
  gdAppointmentSchema
    .find({ gdid: req.params.id, status: "pending" })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

//View  Cust by ID

const approveRequestByGd = (req, res) => {
  gdAppointmentSchema
    .findByIdAndUpdate({ _id: req.params.id }, { status: "accepted" })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

//View  Cust by ID

const rejectRequestByGd = (req, res) => {
  gdAppointmentSchema
    .findByIdAndUpdate({ _id: req.params.id }, { status: "rejected" })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};
//view gd reqs by admin

const viewGDReqs = (req, res) => {
  gd.find()
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

//Approve by media

const approveGDById = (req, res) => {
  gd.findByIdAndUpdate({ _id: req.params.id }, { isactive: true })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

module.exports = {
  registerGD,
  loginGD,
  viewFGDById,
  viewGDs,
  editGDById,
  forgotPassword,
  delGDById,
  viewAppointmentReqsByGd,
  approveRequestByGd,
  requestApponitmentGD,
  rejectRequestByGd,
  viewGDReqs,
  approveGDById,
  upload,
};
