const mongoose = require("mongoose");

const Schema = mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  type: {
    type: String,
    required: true,
  },
  image: {
    type: Object,
  },
  addedby: {
    type: String,
    required: true,
  },
  custId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "customers",
  },
  cost: {
    type: Number,
    required: true,
  },
  feedback: {
    type: Array,
  },
  isactive:{
    type:Boolean,
    default:false
  }
});

module.exports = mongoose.model("plants", Schema);
