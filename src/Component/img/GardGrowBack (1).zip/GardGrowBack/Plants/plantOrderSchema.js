const mongoose=require('mongoose')

const cSchema=mongoose.Schema({
        
    userid:{
        type:mongoose.Schema.Types.ObjectId ,
    ref:'customers'
   },
   count:Number,
   plantid: {type:mongoose.Schema.Types.ObjectId ,
   ref:'plants',
   required:true
  },
    date:{
        type:Date
  
},price:Number

})


module.exports=mongoose.model('plantorders',cSchema)