const plantOrderSchema = require("./plantOrderSchema");
const plants = require("./plantSchema");
const multer = require("multer");
// const cart = require('../user/cart_model')

const storage = multer.diskStorage({
  destination: function (req, res, cb) {
    cb(null, "./upload");
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});

const upload = multer({ storage: storage }).single("image");

// Registration

const addplant = (req, res) => {
  let images = req.file;
  if((req.body.addedby)=="guide")
  isactive=true
  else
  isactive=false
  const newPlant = new plants({
    name: req.body.name,
    cost: req.body.cost,
    type: req.body.type,
    image: images,
    addedby: req.body.addedby,
    custId: req.body.custId,
    guideId: req.body.guideId,
    isactive:isactive
  });
  newPlant
    .save()
    .then((data) => {
      res.json({
        status: 200,
        msg: "Inserted successfully",
        data: data,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Inserted",
        Error: err,
      });
    });
};

// Registration -- finished

//View all

const viewPlants = (req, res) => {
  plants
    .find({isactive:true})
    .populate("custId")
    .exec()
    .then((data) => {
      if (data.length > 0) {
        res.json({
          status: 200,
          msg: "Data obtained successfully",
          data: data,
        });
      } else {
        res.json({
          status: 200,
          msg: "No Data obtained ",
        });
      }
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Inserted",
        Error: err,
      });
    });
};

const viewAllPlants = (req, res) => {
  plants
    .find({})
    .populate("custId")
    .exec()
    .then((data) => {
      if (data.length > 0) {
        res.json({
          status: 200,
          msg: "Data obtained successfully",
          data: data,
        });
      } else {
        res.json({
          status: 200,
          msg: "No Data obtained ",
        });
      }
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Inserted",
        Error: err,
      });
    });
};

//View Plants added by guide

const viewPlantsForGuide = (req, res) => {
  plants
    .find({ addedby: "guide" })
    .exec()
    .then((data) => {
      if (data.length > 0) {
        res.json({
          status: 200,
          msg: "Data obtained successfully",
          data: data,
        });
      } else {
        res.json({
          status: 200,
          msg: "No Data obtained ",
        });
      }
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Inserted",
        Error: err,
      });
    });
};

// view by custid

const viewPlantsForCustId = (req, res) => {
  plants
    .find({ addedby: "customer", custId: req.params.id })
    .exec()
    .then((data) => {
      if (data.length > 0) {
        res.json({
          status: 200,
          msg: "Data obtained successfully",
          data: data,
        });
      } else {
        res.json({
          status: 200,
          msg: "No Data obtained ",
        });
      }
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Inserted",
        Error: err,
      });
    });
};

const viewPlantById = (req, res) => {
  plants
    .findOne({ _id: req.params.id })
    .exec()
    .then((data) => {
      emps = data;
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

// view order for a plant
const viewPlantOrderById = (req, res) => {
  plantOrderSchema
    .find({ plantid: req.params.id })
    .populate("userid")
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};
const delPlantById = (req, res) => {
  plants
    .findByIdAndDelete({ _id: req.params.id })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};
//update Plant by id
const editPlantById = (req, res) => {
  let images = req.file;

  plants
    .findByIdAndUpdate(
      { _id: req.params.id },
      {
        name: req.body.name,

        type: req.body.type,
        image: images,
        addedby: req.body.addedby,
        custId: req.body.custId,
        cost: req.body.cost,
        guideId: req.body.guideId,
      }
    )
    .exec()
    .then((data) => {
      res.json({
        status: 200,
        msg: "Updated successfully",
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "Data not Updated",
        Error: err,
      });
    });
};

// Approve Plant by id by admin
const approvePlantById = (req, res) => {
  plants
    .findByIdAndUpdate({ _id: req.params.id },{isactive:true})
    .exec()
    .then((data) => {
      emps = data;
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

module.exports = {
  addplant,
  viewPlants,
  viewAllPlants,
  upload,
  viewPlantsForCustId, // customer customer plants only
  viewPlantsForGuide, // admin - all plants by all guide
  viewPlantById,
  delPlantById,
  editPlantById,
  viewPlantOrderById,
  approvePlantById
};
