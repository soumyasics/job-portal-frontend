const mongoose = require("mongoose");

const cSchema = mongoose.Schema({
  userid: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "customers",
  },

  plantid: { type: mongoose.Schema.Types.ObjectId, ref: "plants" },
  date: {
    type: Date,
  },
});

module.exports = mongoose.model("plantwishlists", cSchema);
