const orderSchema = require("./plantOrderSchema");
const plantSchema = require("./plantSchema");
const plantWishlistSchema = require("./plantWishlistSchema");

const addtoOrders = async (req, res) => {
  date = new Date();

  const obj = new orderSchema({
    plantid: req.body.plantid,
    userid: req.body.userid,
    price: req.body.price,
    date: date,
    count: req.body.count,
  });
  obj.save((err, data) => {
    if (err) {
      res.json({
        status: 500,
        err: err,
        message: err.message,
      });
    } else {
      res.json({
        status: 200,
        data: data,
        message: "Successfully saved",
      });
    }
  });
};

// view order by id
const viewOrderById = (req, res) => {
  orderSchema
    .findOne({ _id: req.params.id })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

// view orders  by custid
const viewOrderByCustomerId = (req, res) => {
  orderSchema
    .find({ userid: req.params.id })
    .populate("plantid")
    .populate("userid")

    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};
const viewAllOrders = (req, res) => {
  orderSchema
    .find()
    .populate("plantid")
    .populate("userid")

    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

// remove order  by id
const removeOrderById = (req, res) => {
  orderSchema
    .findByIdAndDelete({ _id: req.params.id })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data removed successfully",
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

// view orders  by custid
const viewOrdersForACustomerId = async (req, res) => {
  let plants = [];
  let orders = [];
  await orderSchema
    .find({})
   
    .exec()
    
    .then((data) => {
      data.map((x) => {
        plants.push(x.plantid);
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
  await plantSchema
    .find({ _id: { $in: plants } })
   
    .exec()
    .then((datas) => {
      console.log("orsedred plants", datas);
      datas.map((x) => {
        if (x.addedby == "customer" && x.custId == req.params.id) {
          orders.push(x._id);
        }
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
  console.log("orderde", orders);

  await plantSchema
    .find({ _id: { $in: orders } }).populate('custId')
    .exec()
    .then((datass) => {
      res.json({
        status: 200,
        msg: "Data obtained",
        data: datass,
      });
    })
    .catch((err) => {
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};
module.exports = {
  addtoOrders,
  viewOrderById,
  viewOrderByCustomerId,
  removeOrderById,
  viewOrdersForACustomerId,
  viewAllOrders
};
