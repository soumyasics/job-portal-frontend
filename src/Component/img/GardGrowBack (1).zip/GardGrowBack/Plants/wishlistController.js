const plantWishlistSchema = require("./plantWishlistSchema");

const addtoWishlist = async (req, res) => {
  date = new Date();

  const obj = new plantWishlistSchema({
    plantid: req.body.plantid,
    userid: req.body.userid,
    date: date,
  });
  obj.save((err, data) => {
    if (err) {
      res.json({
        status: 500,
        err: err,
        message: err.message,
      });
    } else {
      res.json({
        status: 200,
        data: data,
        message: "Successfully saved",
      });
    }
  });
};

// view order by id
const viewWishlistById = (req, res) => {
  plantWishlistSchema
    .findById({ _id: req.params.id })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

// view wishlist  by custid
const viewWishlistyCustomerId = (req, res) => {
  plantWishlistSchema
    .find({ userid: req.params.id })
    .populate("plantid")
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data obtained successfully",
        data: data,
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

// remove wishlist  by id
const removeWishListById = (req, res) => {
  plantWishlistSchema
    .findByIdAndDelete({ _id: req.params.id })
    .exec()
    .then((data) => {
      console.log(data);
      res.json({
        status: 200,
        msg: "Data removed successfully",
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: 500,
        msg: "No Data obtained",
        Error: err,
      });
    });
};

module.exports = {
  addtoWishlist,
  viewWishlistById,
  viewWishlistyCustomerId,
  removeWishListById,
};
