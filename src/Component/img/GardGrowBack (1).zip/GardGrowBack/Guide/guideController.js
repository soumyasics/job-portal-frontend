

const guide=require('./guideSchema')
const jwt=require('jsonwebtoken')

const secret = 'your-secret-key'; // Replace this with your own secret key

const createToken = (user) => {
  return jwt.sign({ userId: user._id }, secret, { expiresIn: '1h' });
};


// Registration 

const registerGuide=(req,res)=>{
    const newGD=new guide({
        name:req.body.name,
        
        
        contact:req.body.contact,
        email:req.body.email,
        password:req.body.password
    })
    newGD.save().then(data=>{
        res.json({
            status:200,
            msg:"Inserted successfully",
            data:data
        })
    }).catch(err=>{
        res.json({
            status:500,
            msg:"Data not Inserted",
            Error:err
        })
    })
}
// Registration -- finished

//Login  
const loginGD=(req,res)=>{
  

  
    const { email, password } = req.body;
  
    guide.findOne({ email }).exec().then (user => {
     
  
      if (!user) {
        return res.status(404).json({ msg: 'User not found' });
      }
  
        if (user.password!=password) {
          return res.status(500).json({ msg:'incorrect pwd' });
        }
  
      
        const token = createToken(user);
  
        res.status(200).json({ user, token });
      })
      .catch(err=>{
        console.log(err);
          return res.status(500).json({ msg: 'Something went wrong' });
        
      })
    
  };
  //validate
  
  
  const requireAuth = (req, res, next) => {
    const token = req.headers.authorization.split(' ')[1];
  
    console.log("t1",token);
    console.log("secret",secret);
    if (!token) {
      return res.status(401).json({ msg: 'Unauthorized' });
    }
    jwt.verify(token, secret, (err, decodedToken) => {
      console.log(decodedToken);
      if (err) {
        return res.status(401).json({ messamsgge: 'Unauthorized' ,err:err});
      }
  
      req.user = decodedToken.userId;
      next();
      return res.status(200).json({ msg: 'ok' ,user:decodedToken.userId});
    });
    console.log(req.user);
  };
  
  //Login  --finished
  


//View all 

const viewGDs=(req,res)=>{
  guide.find().exec()
  .then(data=>{
    if(data.length>0){
    res.json({
        status:200,
        msg:"Data obtained successfully",
        data:data
    })
  }else{
    res.json({
      status:200,
      msg:"No Data obtained "
  })
  }
}).catch(err=>{
    res.json({
        status:500,
        msg:"Data not Inserted",
        Error:err
    })
})

}

// view  finished


//update  by id
const editGDById=(req,res)=>{

  
    
  guide.findByIdAndUpdate({_id:req.params.id},{
    name:req.body.name,
 
    
    contact:req.body.contact,
    email:req.body.email
    })
.exec().then(data=>{
  res.json({
      status:200,
      msg:"Updated successfully"
  })
}).catch(err=>{
  res.json({
      status:500,
      msg:"Data not Updated",
      Error:err
  })
})
}


// forgot password
const forgotPassword=(req,res)=>{
  guide.findOne({email:req.body.email}).exec()
  
  .then(data=>{
    console.log(data);
    if(data==null){
      res.json({
        status:500,
        msg:"User not Found"
    })
    }
    else{
      guide.findOneAndUpdate({email:req.body.email},{
        password:req.body.password
      }).exec().then(data=>{
        res.json({
          status:200,
          msg:"Updated successfully"
      })
    }).catch(err=>{
      res.json({
          status:500,
          msg:"Data not Updated",
          Error:err
      })
    })
    }
  })
}
//finished -- forgot password
//View   by ID

const viewGuideById=(req,res)=>{
  guide.findOne({_id:req.params.id}).exec()
  .then(data=>{

    console.log(data);
    res.json({
        status:200,
        msg:"Data obtained successfully",
        data:data
    })
  
}).catch(err=>{
  console.log(err);
    res.json({
        status:500,
        msg:"No Data obtained",
        Error:err
    })
})

}
//View  Cust by ID

const delFGDById=(req,res)=>{
    guide.findByIdAndDelete({_id:req.params.id}).exec()
    .then(data=>{
  
      console.log(data);
      res.json({
          status:200,
          msg:"Data obtained successfully",
          data:data
      })
    
  }).catch(err=>{
    console.log(err);
      res.json({
          status:500,
          msg:"No Data obtained",
          Error:err
      })
  })
  
  }



module.exports={registerGuide,loginGD,viewGuideById,viewGDs,editGDById,forgotPassword,delFGDById}