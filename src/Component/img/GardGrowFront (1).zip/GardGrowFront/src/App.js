import React, { useEffect, useState } from "react";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./Assets/styles/Navbar.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";

import Nav from "./Component/Navbar/Nav";
import Home from "./Component/Home";
import About from "./Component/About";
import Footer from "./Component/Footer";
import Adminlogin from "./Component/Admin/Adminlogin";
import GarLogin from "./Component/Login/GarLogin";
import FlorLogin from "./Component/Login/FlorLogin";
import Customer from "./Component/Login/Customer";
import GardReg from "./Component/Register/GardReg";
import FlorReg from "./Component/Register/FlorReg";
import CustReg from "./Component/Register/CustReg";
import GDHome from "./Component/GD profile/GDHome";
import GDViewProf from "./Component/GD profile/GDViewProf";
import GDEditProf from "./Component/GD profile/GDEditProf";
import FlorEditProf from "./Component/Florist profile/FlorEditProf";
import FlorViewProf from "./Component/Florist profile/FlorViewProf";
import FlorHome from "./Component/Florist profile/FlorHome";
import FlorNav from "./Component/Navbar/FlorNav";
import CustViewProf from "./Component/CustomerProf/CustViewProf";
import CustEditProf from "./Component/CustomerProf/CustEditProf";
import CustHome from "./Component/CustomerProf/CustHome";
import AdminAbout from "./Component/Admin/AdminAbout";
import AdminNav from "./Component/Navbar/AdminNav";
import AdminHome from "./Component/Admin/AdminHome";
import AdminPage from "./Component/Admin/AdminPage";
import AddCustPlant from "./Component/AddCustPlant";
import ViewPlantCust from "./Component/CustomerProf/ViewPlantCust";
import Guide from "./Component/Login/Guide";
import GuideReg from "./Component/Register/GuideReg";
import GuideHome from "./Component/GuideProf/GuideHome";
import GuideViewProf from "./Component/GuideProf/GuideViewProf";
import GuideEditProf from "./Component/GuideProf/GuideEditProf";
import AddGuidePlant from "./Component/AddGuidePlant";
import ViewPlantGuide from "./Component/ViewPlantGuide";
import AddDesign from "./Component/GD profile/AddDesign";
import ViewDesign from "./Component/GD profile/ViewDesign";
import ViewDesignFlor from "./Component/ViewDesignFlor";
import AddDesignFlor from "./Component/AddDesignFlor";
import EditViewGD from "./Component/EditViewGd"
import EditFlor from "./Component/EditFlor";
import ViewallplantGuide from "./Component/GuideProf/ViewallplantGuide";
import AddProduc from "./Component/AddProduc";
import ViewProduct from "./Component/CustomerProf/ViewProduct";
import BuyProduct from "./Component/CustomerProf/BuyProduct";
import CustExploView from "./Component/CustomerProf/CustExploView";

import ViewFlorist from "./Component/CustomerProf/ViewFlorist";
import ViewGar from "./Component/CustomerProf/ViewGar"

import Viewflordesign from "./Component/Viewflordesign";
import Viewgardesign from "./Component/CustomerProf/Viewgardesign"

import GuideChat from "./Component/GuideChat";
import FlorAppointment from "./Component/Florist profile/FlorAppointment";
import FlorAbout from "./Component/Florist profile/FlorAbout";
import ConfrimFlor from "./Component/Florist profile/ConfrimFlor";
import GardAppointment from "./Component/GD profile/GardAppointment";
import ConfrimGard from "./Component/GD profile/ConfirmGard";
import FlorCaraosuel from "./Component/FlorCarousel";
import CustCaraosuel from "./Component/CustCarousel";
import GuideCaraosuel from "./Component/GuideCarousel";
import Navbar from "./Component/Navbar/Navbar";
import ViewMyPlants from "./Component/CustomerProf/ViewMyPlants";
import ReceivedPlantOrders from "./Component/CustomerProf/ReceivedPlantOrders";
import ViewMyProductOrders from "./Component/CustomerProf/ViewMyProductOrders";
import ViewMyGDDesOrder from "./Component/CustomerProf/ViewMyGDDesOrder";
import ViewMyFlorDesOrder from "./Component/CustomerProf/ViewMyFlorDesOrder";
import ViewMyPlantOrders from "./Component/CustomerProf/ViewMyPlantOrders";
import ChatGD from "./Component/Chat/ChatGD";
import ChatFlor from "./Component/Chat/ChatFlor";
import ChatGDtoCust from "./Component/Chat/ChatGDtoCust";
import ChatFlortoCust from "./Component/Chat/ChatFlottoCust";
import ChatGuide from "./Component/Chat/ChatGuide";
import ChatGuidetoCust from "./Component/Chat/ChatGuidetoCust";
import Wishlist from "./Component/CustomerProf/Wishlist";
function App() {

  const [auth, setauth] = useState(0)

  useEffect(() => {

    if(localStorage.getItem(`custlogid`)!=null){
      setauth(1)
    }
    else if(localStorage.getItem(`florlogid`)!=null){
      setauth(2)
    }
    else if(localStorage.getItem(`Gdlogid`)!=null){
      setauth(3)
    }
    else if(localStorage.getItem(`guidelogid`)!=null){
      setauth(4)
    }
    else if(localStorage.getItem(`adminlog`)!=null){
      setauth(5)
    }
    else{
      setauth(0)
    }
  })
  return (
    <BrowserRouter basename="/projects/gard_grow">

      <div>
        <Navbar auth={auth} />
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/About" element={<About />} />


          <Route path="/Admin" element={<Adminlogin />} />
          <Route path="/AdminAbout" element={<AdminAbout />} />
          <Route path="/AdminHome" element={<AdminHome />} />
          <Route path="/Adminpage" element={<AdminPage />} />


          <Route path="/GarLogin" element={<GarLogin />} />
          <Route path="/FlorLogin" element={<FlorLogin />} />
          <Route path="/Customer" element={<Customer />} />

          <Route path="/GardReg" element={<GardReg />} />
          <Route path="/FlorReg" element={<FlorReg />} />
          <Route path="/CustReg" element={<CustReg />} />
          <Route path="/GuideReg" element={<GuideReg />} />

          <Route path="/GDHome" element={<GDHome />} />
          <Route path="/GDViewProf" element={<GDViewProf />} />
          <Route path="/GDEditProf" element={<GDEditProf />} />


          <Route path="/FlorHome" element={<FlorHome />} />
          <Route path="/FlorNav" element={<FlorNav />} />
          <Route path="/FlorEditProf" element={<FlorEditProf />} />
          <Route path="/FlorViewProf" element={<FlorViewProf />} />

          <Route path="/CustHome" element={<CustHome />} />
          <Route path="/CustViewProf" element={<CustViewProf />} />
          <Route path="/CustEditProf" element={<CustEditProf />} />
          <Route path="/AddCustPlant" element={<AddCustPlant />} />
          <Route path="/ViewCustPlant" element={<ViewPlantCust />} />
          <Route path="/Wishlist" element={<Wishlist />} />

          <Route path="/ViewMyPlants" element={<ViewMyPlants/>} />
          <Route path="/ViewMyOrders" element={<ViewMyProductOrders/>} />

          <Route path="/ReceivedPlantOrders" element={<ReceivedPlantOrders/>} />

          <Route path="/ViewMyGDDesOrder" element={<ViewMyGDDesOrder/>} />
          <Route path="/ViewMyFlorDesOrder" element={<ViewMyFlorDesOrder/>} />
          <Route path="/ViewMyProductOrders" element={<ViewMyProductOrders/>} />
          <Route path="/ViewMyPlantOrders" element={<ViewMyPlantOrders/>} />


          
          
          <Route path="/GuideHome" element={<GuideHome />} />
          <Route path="/GuideViewProf" element={<GuideViewProf />} />
          <Route path="/GuideEditProf" element={<GuideEditProf />} />
          <Route path="/AddGuidePlant" element={<AddGuidePlant />} />
          <Route path="/ViewGuidePlant" element={<ViewPlantGuide />} />
          <Route path="/Guide" element={<Guide />} />



         
          <Route path="/AddDesignFlor" element={<AddDesignFlor />} />
          <Route path="/ViewDesignFlor" element={<ViewDesignFlor />} />

          <Route path="/AddDesign" element={<AddDesign />} />
          <Route path="/ViewDesign" element={<ViewDesign />} />


          

          <Route path="/EditViewGD/:cardid" element={<EditViewGD />} />
          <Route path="/EditFlor/:cardid" element={<EditFlor />} />

          <Route path="/ViewallplantGuide" element={<ViewallplantGuide />} />

          <Route path="/AddProduc" element={<AddProduc />} />
          <Route path="/ViewProduct" element={<ViewProduct />} />
          <Route path="/BuyProduct/:id/:cost" element={<BuyProduct />} />

          <Route path="/CustExploView" element={<CustExploView />} />

          <Route path="/ViewFlorist" element={<ViewFlorist />} />
          <Route path="/ViewGar" element={<ViewGar />} />
          <Route path="/viewflordesign/:id" element={<Viewflordesign />} />
          <Route path="/Viewgardesign/:id" element={<Viewgardesign />} />

        
          <Route path="/GuideChat" element={<GuideChat />} />

          <Route path="/FlorAppointment" element={<FlorAppointment />} />
          <Route path="/FlorAbout" element={<FlorAbout />} />

          <Route path="/ConfrimFlor/:id" element={<ConfrimFlor />} />
          <Route path="/GardAppoinment" element={<GardAppointment />} />
          <Route path="/ConfrimGard/:id" element={<ConfrimGard />} />

          <Route path="/FlorCarousel" element={<FlorCaraosuel />} />
          <Route path="/CustCarousel" element={<CustCaraosuel />} />

          <Route path="/GuideCarousel" element={<GuideCaraosuel />} />

          <Route path="/ChatGD/:gdid" element={<ChatGD/>} />
          <Route path="/ChatFD/:fdid" element={<ChatFlor/>} />
          <Route path="/Chatguide" element={<ChatGuide/>} />

          <Route path="/ChatGDtoCust" element={<ChatGDtoCust/>} />
          <Route path="/ChatFlottoCust" element={<ChatFlortoCust/>} />
          <Route path="/ChatGuidetoCust" element={<ChatGuidetoCust/>}/>

        </Routes>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
