import React, { useEffect, useState } from "react";
import axiosInstance from "../../Baseurl";
import { Link, useNavigate } from "react-router-dom";

function ViewMyPlantOrders() {
  const [Plant, setPlant] = useState([]);
  const [cust,setcust] = useState([])

  const Navigate = useNavigate();
  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        Navigate('/home')
      }
    });


    
  useEffect(() => {
    axiosInstance
      .post(`/viewOrderByCustomerId/${localStorage.getItem(`custlogid`)}`)
      .then((res) => {
        console.log(res);
        if (res.data.data != undefined) {
          setPlant(res.data.data);
        }
      })
      .catch((res) => {
        console.log(res);
      });

      axiosInstance.post(`/viewCustomers`)
      .then((res)=>{console.log(res)
      if(res.data.data!=undefined){
        setcust(res.data.data)
      }})
      .catch((err)=>{console.log(err);})
  }, []);
  return (
    <>
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {Plant.length ? (
              Plant.map((a) => {
                let x 
                for(let i of cust){
                  if(i._id==a.plantid.custId){
                   x=i.name
                  }
                }
                return (
                  <div class="col-4">
                    <div class="card">
                    <img
                          src={`http://localhost:4010/${a.plantid.image.originalname}`}
                          class="card-img-top"
                          alt="..."
                          height="340px"
                        />
                    <div class="card-body">
                        <h5 class="card-title">Plant : {a.plantid.name}</h5>
                        <p class="card-text">Type : {a.plantid.type}</p>
                        <p class="card-text">Price : {a.price}$</p>
                        <p class="card-text">Count : {a.count}</p>
                        <hr/>
                        <h5> seller : {x}</h5>
                        <h4> Ordered Date : {a.date.slice(0,10)}</h4>

                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div class="col-12">
                <div class="card">
                  <div class="card-body"> 
                    <h5 class="card-title">No data</h5>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default ViewMyPlantOrders