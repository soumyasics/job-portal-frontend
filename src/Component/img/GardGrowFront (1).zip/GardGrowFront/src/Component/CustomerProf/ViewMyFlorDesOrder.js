import React, { useEffect, useState } from "react";
import axiosInstance from "../../Baseurl";
import { Link, useNavigate } from "react-router-dom";
function ViewMyFlorDesOrder()  {
  const [Flor, setFlor] = useState([]);
  
  const Navigate = useNavigate();


  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        Navigate('/home')
      }
    });

   useEffect(() => {
    axiosInstance
      .post(`/viewAprvdFlorAppointnmentsByCustomerId/${localStorage.getItem(`custlogid`)}`)
      .then((res) => {
        console.log(res);
        if (res.data.data != undefined) {
          setFlor(res.data.data);
        }
      })
      .catch((res) => {
        console.log(res);
      });
  }, []);
  return (
    <>
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {Flor.length ? (
              Flor.map((a) => {
                if(a.fid!=null){
                  return (
                    <div class="col-4" key={a._id}>
                  <div class="card">
                    <div class="card-body">
                      <h5 class="card-title">Florist : {a.fid.name}</h5>
                      <p class="card-text">Contact : {a.fid.contact}</p>
                      <p class="card-text">email: {a.fid.email}$</p>
                      <h5> Status:  {a.time?<span style={{color:"green"}}> Approved</span>:<span style={{color:"red"}}> Pending </span>} </h5>
                      <h5>  {a.time?<span style={{color:"green"}}> Time : {a.time} <hr/> Date : {a.date.slice(0,10)}</span>:null} </h5>
                      {a.time?<Link className="btn btn-primary" to={`/ChatFD/${a.fid._id}`}> Chat</Link>:null}
                    </div>
                  </div>
                </div>
                );
                }
                
              })
            ) : (
              <div class="col-12">
                <div class="card">
                  <div class="card-body"> 
                    <h5 class="card-title">No data</h5>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default ViewMyFlorDesOrder