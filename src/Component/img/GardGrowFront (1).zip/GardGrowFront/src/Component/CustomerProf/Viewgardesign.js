import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axiosInstance from "../../Baseurl";

function Viewgarrdesign() {
  const { id } = useParams();
  const [viewgar, setviewgar] = useState([]);


  const Navigate = useNavigate();


  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        Navigate('/home')
      }
    });


    
  useEffect(() => {
    axiosInstance
      .post(`/viewDesignByGDid/${id}`)
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          setviewgar(res.data.data);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  const handleAppoinment = () => {
    axiosInstance
      .post(`/addAppointmentGD`, {
        gdid: id,
        userid: localStorage.getItem("custlogid"),
      })
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          alert("Appoinment Requested");
          Navigate("/CustExploView");
        } else {
          alert("failed");
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <div>
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {viewgar.length ? (
              viewgar.map((a) => {
                return (
                  <div class="col-6">
                    <div class="card">
                      <img
                        src={`http://localhost:4010/${a.image.originalname}`}
                        class="card-img-top"
                        alt="..."
                        height="340px"
                      />
                      <div class="card-body">
                        <h5 class="card-title">{a.title}</h5>
                        <p class="card-text">Type: {a.type}</p>
                        <p class="card-text">Price: {a.cost}$</p>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div class="col">
                <div
                  class="card"
                  style={{ width: "300px", margin: "11px auto" }}
                >
                  <div class="card-body">
                    <h5 class="card-title">No data</h5>
                  </div>
                </div>
              </div>
            )}
          </div>
          <div className="row" style={{margin:"30px"}}>
         <div className="col">
         <button onClick={() => {handleAppoinment()}} class="btn btn-primary">Book an Appoinment</button>
         </div>
          </div>
          
        </div>
      </div>
    </div>
  );
}

export default Viewgarrdesign;
