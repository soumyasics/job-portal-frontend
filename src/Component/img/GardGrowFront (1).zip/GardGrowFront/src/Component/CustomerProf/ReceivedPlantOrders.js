import React, { useEffect, useState } from "react";
import axiosInstance from "../../Baseurl";
import { Link, useNavigate } from "react-router-dom";

function ReceivedPlantOrders() {
  const [RecPlant, setRecPlant] = useState([]);

  const navigate=useNavigate();

  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        navigate('/home')
      }
    });

    
  useEffect(() => {
    axiosInstance
      .post(`/viewAllOrders`)
      .then((res) => {
        console.log(res);
        if (res.data.data != undefined) {
          setRecPlant(res.data.data);
        }
      })
      .catch((res) => {
        console.log(res);
      });
  }, []);
  return (
    <>
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {RecPlant.length ? (
              RecPlant.map((a) => {
                if(a.plantid.custId==localStorage.getItem('custlogid')){
                  return (
                    <div class="col-4">
                      <div class="card">
                        
                      <div class="card-body">
                        <h4> Buyer : {a.userid.name}</h4>
                          <h5 class="card-title">Plant : {a.plantid.name}</h5>
                          <p class="card-text">Type: {a.plantid.type}</p>
                          <p class="card-text">Price: {a.price}$</p>
                          <p class="card-text">Count: {a.count}</p>
  
                        </div>
                      </div>
                    </div>
                  );
                }
                
              })
            ) : (
              <div class="col-12">
                <div class="card">
                  <div class="card-body"> 
                    <h5 class="card-title">No data</h5>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default ReceivedPlantOrders