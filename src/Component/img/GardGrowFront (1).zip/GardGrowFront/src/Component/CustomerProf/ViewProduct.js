import React, { useEffect, useState } from "react";

import axiosInstance from "../../Baseurl";
import { Link, useNavigate } from "react-router-dom";

function ViewProduct() {

  const Navigate = useNavigate();
  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        Navigate('/home')
      }
    });

  const [prod, setprod] = useState([]);
  const [userid, setuserid] = useState({});

  const id = localStorage.getItem("custlogid");

  const [register, setRegister] = useState({
    plantid: "",
    userid: id,
  });
  useEffect(() => {
    axiosInstance
      .post(`/viewProducts`)
      .then((res) => {
        console.log(res, "viewguideproduct");
        if (res.data.data) {
          setprod(res.data.data);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  
  const handleWhislist = (id) => {
    setRegister({ ...register, plantid: id });
    axiosInstance
      .post(`/addtoWishlist`)
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          alert("added to wishlist");
          // Navigate("/CustExploView");
          // window.location.reload()
        } else {
          alert("failed");
          // alert.warning('Employee Already Exist')
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <>


      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {prod.length ? (
              prod.map((a) => {
                return (
                  <div class="col">
                    <div
                      class="card"
                      style={{ width: "300px", margin: "auto" }}
                    >
                     <img src={`http://localhost:4010/${a.image.originalname}`} class="card-img-top" alt="..." height={'300px'}/>
                      <div class="card-body">
                        <h5 class="card-title">{a.name}</h5>
                        <p class="card-text">Type: {a.type}</p>
                        <p class="card-text">Price: {a.cost}$</p>

                        <Link
                          to={`/BuyProduct/${a._id}/${a.cost}`}
                          class="btn btn-primary"
                        >
                          Buy
                        </Link>
                        <Link
                          class="btn btn-success"
                          onClick={() => {
                            handleWhislist(a._id);
                          }}
                          style={{ marginLeft: "2rem" }}
                        >
                          Wishlist
                        </Link>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div class="col">
                    <div
                      class="card"
                      style={{ width: "300px", margin: "auto" }}
                    >
                     
                      <div class="card-body">
                        <h5 class="card-title">No data</h5>
                       
                      </div>
                    </div>
                  </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
    
}

export default ViewProduct;
