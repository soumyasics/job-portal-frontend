import React, { useEffect, useState } from "react";
import axiosInstance from "../../Baseurl";
import { Link, useNavigate } from "react-router-dom";

function ViewMyProductOrders() {
  const [Product, setproduct] = useState([]);

  const Navigate = useNavigate();
  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        Navigate('/home')
      }
    });



  useEffect(() => {
    axiosInstance
      .post(`/viewPdtOrderByCustId/${localStorage.getItem(`custlogid`)}`)
      .then((res) => {
        console.log(res);
        if (res.data.data != undefined) {
          setproduct(res.data.data);
        }
      })
      .catch((res) => {
        console.log(res);
      });
  }, []);
  return (
    <>
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {Product.length ? (
              Product.map((a) => {
                if (a.userid == localStorage.getItem("custlogid")) {
                  return (
                    <div class="col-4">
                      <div class="card">
                       
                        <div class="card-body">
                          <h5 class="card-title">Product : {a.pdtid.name}</h5>
                          <p class="card-text">Type : {a.pdtid.type}</p>
                          <p class="card-text">Price : {a.pdtid.cost}$</p>
                          <p class="card-text">Count : {a.count}</p>

                          <h4> Ordered Date : {a.date.slice(0,10)}</h4>
                          <Link className="btn btn-primary" to={`/Chatguide`}> Chat</Link>

                        </div>
                      </div>
                    </div>
                  );
                }
              })
            ) : (
              <div class="col-12">
                <div class="card">
                  <div class="card-body"> 
                    <h5 class="card-title">No data</h5>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default ViewMyProductOrders;
