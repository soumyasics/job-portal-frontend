import React, { useEffect, useState } from "react";
import axiosInstance from "../../Baseurl";
import { Link, useNavigate } from "react-router-dom";

function Wishlist() {
  const [flowers, setflowers] = useState([]);

  const Navigate = useNavigate();
  useEffect(() => {
    if (localStorage.getItem("custlogid") == null) {
      Navigate("/home");
    }
  });

  const [order, setorder] = useState({
    plantid: "",
    userid: localStorage.getItem("custlogid"),
    price: "",
    count: "",
  });
  useEffect(() => {
    axiosInstance
      .post(`/viewWishlistyCustomerId/${localStorage.getItem(`custlogid`)}`)
      .then((res) => {
        console.log(res);
        if (res.data.data != undefined) {
          setflowers(res.data.data);
        }
      })
      .catch((res) => {
        console.log(res);
      });
  }, []);

  const subfn = (e) => {
    e.preventDefault();
    axiosInstance
      .post(`/addtoorders`, order)
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          alert("Order Placed");
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const removefromwishlist = (id) => {
    axiosInstance
      .post(`/removeWishListById/${id}`)
      .then((res) => {
        console.log(res);
        alert("removed from wishlist");
        window.location.reload(false)
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <>
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {flowers.length ? (
              flowers.map((a) => {
                return (
                  <div class="col-4">
                    <div class="card">
                      <img
                        src={`http://localhost:4010/${a.plantid.image.originalname}`}
                        class="card-img-top"
                        alt="..."
                        height="340px"
                      />
                      <div class="card-body">
                        <h5 class="card-title">{a.plantid.name}</h5>
                        <p class="card-text">Type: {a.plantid.type}</p>
                        <p class="card-text">Price: {a.plantid.cost}$</p>

                        <button
                          type="button"
                          class="btn btn-primary"
                          data-bs-toggle="modal"
                          data-bs-target="#exampleModal"
                          onClick={() => {
                            setorder({
                              ...order,
                              price: a.plantid.cost,
                              plantid: a.plantid._id,
                            });
                          }}
                        >
                          Buy Plant
                        </button>
                        <button
                          className="btn btn-danger"
                          onClick={() => {
                            removefromwishlist(a._id);
                          }}
                        >
                          {" "}
                          Remove From Wishlist{" "}
                        </button>

                        <div
                          class="modal fade"
                          id="exampleModal"
                          tabindex="-1"
                          aria-labelledby="exampleModalLabel"
                          aria-hidden="true"
                        >
                          <div class="modal-dialog">
                            <form onSubmit={subfn}>
                              <div class="modal-content">
                                <div class="modal-body">
                                  <div class="mb-3">
                                    <label class="form-label">
                                      Plant Count
                                    </label>
                                    <input
                                      type="number"
                                      min="1"
                                      onChange={(e) => {
                                        setorder({
                                          ...order,
                                          count: e.target.value,
                                        });
                                      }}
                                      class="form-control"
                                    />
                                  </div>
                                </div>
                                <div class="modal-footer">
                                  <button
                                    type="button"
                                    class="btn btn-secondary"
                                    data-bs-dismiss="modal"
                                  >
                                    Close
                                  </button>
                                  <button type="submit" class="btn btn-primary">
                                    Buy Plant
                                  </button>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div class="col-12">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">No data</h5>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default Wishlist;
