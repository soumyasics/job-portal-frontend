import React, { useEffect, useState } from "react";
import axiosInstance from "../../Baseurl";
import { Link, useNavigate } from "react-router-dom";

function ViewFlorist() {
  const [flor, setflor] = useState([]);

  const navigate=useNavigate();

  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        navigate('/home')
      }
    });
  useEffect(() => {
    axiosInstance
      .post(`/viewFlorists`)
      .then((res) => {
        console.log(res, "viewflordesign");
        if (res.data.data) {
          setflor(res.data.data);
        } else {
          setflor([]);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <div style={{ minHeight: "300px", margin: "15px 0px" }}>
      <div class="container text-center">
        <div class="row">
          {flor.length ? (
            flor.map((a) => {
              return (
                <div class="col-4">
                  <div class="card" >
                    {/* <img
                  src={`http://localhost:4010/${a.image.originalname}`}
                  class="card-img-top"
                  alt="..."
                  height="240px"
                /> */}
                    <div class="card-body">
                      <h5 class="card-title">{a.name}</h5>
                      <p class="card-text">City: {a.city}</p>
                      <p class="card-text">Contact: {a.contact}</p>

                      <Link
                        to={`/viewflordesign/${a._id}`}
                        className="btn btn-primary"
                      >
                        Book Appoinment
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div class="col">
              <div class="card" style={{ width: "300px", margin: "auto" }}>
                <div class="card-body">
                  <h5 class="card-title">No Data</h5>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ViewFlorist;
