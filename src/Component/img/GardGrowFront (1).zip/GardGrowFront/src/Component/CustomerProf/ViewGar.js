import React, { useEffect, useState } from "react";
import axiosInstance from "../../Baseurl";
import { Link, useNavigate } from "react-router-dom";

function ViewFlorist() {
  const [gar, setgar] = useState([]);

  const navigate=useNavigate();

  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        navigate('/home')
      }
    });
  useEffect(() => {
    axiosInstance
      .post(`/viewGDs`)
      .then((res) => {
        console.log(res, "viewgardesign");
        if (res.data.data) {
          setgar(res.data.data);
        } else {
          setgar([]);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  if (localStorage.getItem("custlogid") != null) {
    return (
      <>
        <div style={{ minHeight: "300px", margin: "15px 0px" }}>
          <div class="container text-center">
            <div class="row">
              {gar.length ? (
                gar.map((a) => {
                  return (
                    <div class="col-4">
                      <div class="card">
                        {/* <img
                        src={`http://localhost:4010/${a.image.originalname}`}
                        class="card-img-top"
                        alt="..."
                        height="240px"
                      /> */}
                        <div class="card-body">
                          <h5 class="card-title">{a.name}</h5>
                          <p class="card-text">Email : {a.email}</p>
                          <p class="card-text">Contact: {a.contact}</p>

                          <Link
                            to={`/Viewgardesign/${a._id}`}
                            className="btn btn-primary"
                          >
                            Book Appoinment
                          </Link>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div class="col-12">
                  <div class="card" style={{ width: "300px", margin: "auto" }}>
                    {/* <img
                  src={`http://localhost:4010/${a.image.originalname}`}
                  class="card-img-top"
                  alt="..."
                  height="240px"
                /> */}
                    <div class="card-body">
                      <h5 class="card-title">No Data</h5>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default ViewFlorist;
