import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import img from "../../img/lotus.webp";
import img2 from "../../img/natural-therapies.jpg";
import img3 from "../../img/FLOR.webp";
import img4 from "../../img/gar.webp";

function CustExploView() {

  const navigate=useNavigate();

  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        navigate('/home')
      }
    });



  return (
    <div style={{padding:"40px"}}>
      <div class="container text-center">
        <div class="row">
          <div class="col-6">
            <div class="card" >
              <img src={img} class="card-img-top" alt="..." height="440px" />
              <div class="card-body">
                <Link to="/ViewCustPlant" class="btn btn-primary">

                  Plant
                </Link>
              </div>
            </div>
          </div>
          <div class="col-6">
            <div class="card" >
              <img src={img2} class="card-img-top" alt="..." height="440px" />
              <div class="card-body">
                <Link to="/ViewProduct" class="btn btn-primary">
                  {" "}
                  Product
                </Link>
              </div>
            </div>
          </div>
          <div class="col-6">
            <div class="card">
              <img src={img3} class="card-img-top" alt="..." height="440px" />
              <div class="card-body">
                <Link to="/ViewFlorist" class="btn btn-primary">
                  Flor Design
                </Link>
              </div>
            </div>
          </div>
          <div class="col-6">
            <div class="card" >
              <img src={img4} class="card-img-top" alt="..." height="440px" />
              <div class="card-body">
                <Link to="/ViewGar" class="btn btn-primary">
                  Gardern Design
                </Link>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

export default CustExploView;
