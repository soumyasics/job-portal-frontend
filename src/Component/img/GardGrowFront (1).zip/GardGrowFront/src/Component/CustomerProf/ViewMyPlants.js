import React, { useEffect, useState } from "react";
import axiosInstance from "../../Baseurl";
import { Link, useNavigate } from "react-router-dom";

function ViewMyPlants() {
  const [flowers, setflowers] = useState([]);

  const Navigate = useNavigate();
  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        Navigate('/home')
      }
    });

  useEffect(() => {
    axiosInstance
      .post(`/viewAllPlants`)
      .then((res) => {
        console.log(res);
        if (res.data.data != undefined) {
          
          setflowers(res.data.data );

        }
      })
      .catch((res) => {
        console.log(res);
      });
  }, []);
  return (
    <>
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {flowers.length ? (
              flowers.map((a) => {
               if(a.addedby=="customer"){
               console.log( localStorage.getItem("custlogid"));
                if (a.custId._id == localStorage.getItem("custlogid")) {
                  return (
                    <div class="col-4">
                      <div class="card">
                        <img
                          src={`http://localhost:4010/${a.image.originalname}`}
                          class="card-img-top"
                          alt="..."
                          height="340px"
                        />
                        <div class="card-body">
                          <h5 class="card-title">{a.name}</h5>
                          <p class="card-text">Type: {a.type}</p>
                          <p class="card-text">Price: {a.cost}$</p>
                        </div>
                      </div>
                    </div>
                  );
                }
               }
              })
            ) : (
              <div class="col-12">
                <div class="card">
                  <div class="card-body"> 
                    <h5 class="card-title">No data</h5>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default ViewMyPlants;
