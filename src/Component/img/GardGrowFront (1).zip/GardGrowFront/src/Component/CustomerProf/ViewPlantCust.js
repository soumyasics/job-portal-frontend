import React, { useEffect, useState } from "react";
import axiosInstance from "../../Baseurl";
import { Link, useNavigate } from "react-router-dom";

function ViewPlantCust() {
  const [flowers, setflowers] = useState([]);

  const Navigate = useNavigate();
  useEffect(() => {
    if (localStorage.getItem("custlogid") == null) {
      Navigate("/home");
    }
  });

  const [order, setorder] = useState({
    plantid: "",
    userid: localStorage.getItem("custlogid"),
    price: "",
    count: "",
  });
  useEffect(() => {
    axiosInstance
      .post(`/viewAllPlants`)
      .then((res) => {
        console.log(res);
        if (res.data.data != undefined) {
          setflowers(res.data.data);
        }
      })
      .catch((res) => {
        console.log(res);
      });
  }, []);

  useEffect(() => {
    console.log(order);
  });

  const subfn = (e) => {
    e.preventDefault();
    axiosInstance
      .post(`/addtoorders`, order)
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          alert("Order Placed");
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const wishlist = (id) => {
    axiosInstance
      .post(`/addtoWishlist`, {
        plantid: id,
        userid: localStorage.getItem(`custlogid`),
      })
      .then((res) => {
        console.log(res);
        alert("Added to Wishlist");
        window.location.reload(false);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <>
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row" >
            {flowers.length ? (
              flowers.map((a) => {
                
                if(a.custId){
                  if (a.custId._id != localStorage.getItem("custlogid")) {
                    return (
                      <div class="col-4" style={{margin:"10px 0px"}}>
                        <div class="card">
                          <img
                            src={`http://localhost:4010/${a.image.originalname}`}
                            class="card-img-top"
                            alt="..."
                            height="340px"
                          />
                          <div class="card-body">
                            <h5 class="card-title">{a.name}</h5>
                            <p class="card-text">Type: {a.type}</p>
                            <p class="card-text">Price: {a.cost}$</p>
  
                            <button
                              type="button"
                              class="btn btn-primary"
                              data-bs-toggle="modal"
                              data-bs-target="#exampleModal"
                              onClick={() => {
                                setorder({
                                  ...order,
                                  price: a.cost,
                                  plantid: a._id,
                                });
                              }}
                            >
                              Buy Plant
                            </button>
  
                            <button
                              type="button"
                              class="btn btn-primary"
                              style={{ margin: "20px" }}
                              onClick={() => {
                                wishlist(a._id);
                              }}
                            >
                              Add to Wishlist
                            </button>
  
                            <div
                              class="modal fade"
                              id="exampleModal"
                              tabindex="-1"
                              aria-labelledby="exampleModalLabel"
                              aria-hidden="true"
                            >
                              <div class="modal-dialog">
                                <form onSubmit={subfn}>
                                  <div class="modal-content">
                                    <div class="modal-body">
                                      <div class="mb-3">
                                        <label class="form-label">
                                          Plant Count
                                        </label>
                                        <input
                                          type="number"
                                          min="1"
                                          onChange={(e) => {
                                            setorder({
                                              ...order,
                                              count: e.target.value,
                                            });
                                          }}
                                          class="form-control"
                                        />
                                      </div>
                                    </div>
                                    <div class="modal-footer">
                                      <button
                                        type="button"
                                        class="btn btn-secondary"
                                        data-bs-dismiss="modal"
                                      >
                                        Close
                                      </button>
                                      <button
                                        type="submit"
                                        class="btn btn-primary"
                                      >
                                        Buy Plant
                                      </button>
                                    </div>
                                  </div>
                                </form>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  }
                }
                else{
                  return (
                    <div class="col-4" style={{
                      margin:"10px 0px"
                    }}>
                      <div class="card">
                        <img
                          src={`http://localhost:4010/${a.image.originalname}`}
                          class="card-img-top"
                          alt="..."
                          height="340px"
                        />
                        <div class="card-body">
                          <h5 class="card-title">{a.name}</h5>
                          <p class="card-text">Type: {a.type}</p>
                          <p class="card-text">Price: {a.cost}$</p>

                          <button
                            type="button"
                            class="btn btn-primary"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            onClick={() => {
                              setorder({
                                ...order,
                                price: a.cost,
                                plantid: a._id,
                              });
                            }}
                          >
                            Buy Plant
                          </button>

                          <button
                            type="button"
                            class="btn btn-primary"
                            style={{ margin: "20px" }}
                            onClick={() => {
                              wishlist(a._id);
                            }}
                          >
                            Add to Wishlist
                          </button>

                          <div
                            class="modal fade"
                            id="exampleModal"
                            tabindex="-1"
                            aria-labelledby="exampleModalLabel"
                            aria-hidden="true"
                          >
                            <div class="modal-dialog">
                              <form onSubmit={subfn}>
                                <div class="modal-content">
                                  <div class="modal-body">
                                    <div class="mb-3">
                                      <label class="form-label">
                                        Plant Count
                                      </label>
                                      <input
                                        type="number"
                                        min="1"
                                        onChange={(e) => {
                                          setorder({
                                            ...order,
                                            count: e.target.value,
                                          });
                                        }}
                                        class="form-control"
                                      />
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                    <button
                                      type="button"
                                      class="btn btn-secondary"
                                      data-bs-dismiss="modal"
                                    >
                                      Close
                                    </button>
                                    <button
                                      type="submit"
                                      class="btn btn-primary"
                                    >
                                      Buy Plant
                                    </button>
                                  </div>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                }
              })
            ) : (
              <div class="col-12" style={{
                margin:"10px 0px"
              }}>
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">No data</h5>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default ViewPlantCust;
