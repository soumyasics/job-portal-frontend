import React, { useState, useEffect } from "react";
import axios from "axios";
import axiosInstance from "../Baseurl";
import { useNavigate } from "react-router-dom";

const ViewOrderCust = () => {
  const [productData, setProductData] = useState(null);
  const [loading, setLoading] = useState(true);

  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("custlogid") == null) {
      navigate("/home");
    }
  });


  useEffect(() => {
    axiosInstance
      .post(`/viewOrderByCustomerId/`)
      .then((response) => {
        setProductData(response.data.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
        setLoading(false);
      });
  }, []);

  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : productData ? (
        <div>
          <h2>{productData.name}</h2>
          <p>{productData.description}</p>
          <p>Price: {productData.price}</p>
        </div>
      ) : (
        <p>No data available</p>
      )}
    </div>
  );
};

export default ViewOrderCust;
