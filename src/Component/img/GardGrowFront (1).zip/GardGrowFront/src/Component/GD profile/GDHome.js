import React from 'react'
import GuideCaraosuel from '../GuideCarousel'

function GDHome() {
  return (
    <div>
       
        <GuideCaraosuel/>
    </div>
  )
}

export default GDHome