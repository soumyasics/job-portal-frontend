import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axiosInstance from "../../Baseurl";

function ViewDesign() {
  const [gd, setgd] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("Gdlogid") == null) {
      navigate("/home");
    }
  });


  useEffect(() => {
    axiosInstance
      .post(`/viewDesignByGDid/${localStorage.getItem("Gdlogid")}`)
      .then((res) => {
        console.log(res,"viewdesign");
       if(res.data.data!=undefined){
        setgd(res.data.data);
       }
      })
      .catch((res) => {
        console.log(res);
      });
  }, []);
  const handleRemoveGDesign = (id) => {
    axiosInstance
      .post(`/delDesignByGDId/${id}`)
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          alert("removed");
          window.location.reload();
        } else {
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };
  if (localStorage.getItem("Gdlogid") !=null) {
  return (
    <>
     
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {gd.length?gd.map((a) => {
              return (
                <div class="col-4">
                  <div class="card" >
                    <img
                      src={`http://localhost:4010/${a.image.originalname}`}
                      class="card-img-top"
                      alt="..."
                      height="240px"
                    />
                    <div class="card-body">
                      <h5 class="card-title">{a.title}</h5>
                      <p class="card-text">Type: {a.type}</p>
                      <p class="card-text">Price: {a.cost}₹</p>

                      <button href="#" class="btn btn-primary" onClick={()=>handleRemoveGDesign(a._id)} style={{margin:"10px 0"}}>
                        Delete
                      </button>
                     <Link to={`/EditViewGD/${a._id}`} ><button href="#" class="btn btn-success"  style={{marginLeft:"10px "}}>
                        Edit 
                      </button></Link>
                    </div>
                  </div>
                </div>
              );
            }):<div class="col-12">
            <div class="card" >
              
              <div class="card-body">
                <h5 class="card-title">No Data</h5>
                
              </div>
            </div>
          </div>}
          </div>
        </div>
      </div>
    </>
  );}
}

export default ViewDesign;
