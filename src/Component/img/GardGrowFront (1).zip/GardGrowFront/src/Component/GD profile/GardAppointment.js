import { useEffect, useState } from "react";
import axiosInstance from "../../Baseurl";
import { Link, useNavigate, useParams } from "react-router-dom";

function GardAppointment() {
  const id = localStorage.getItem("Gdlogid");
  const [GardAppointment, setGardAppoinment] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("Gdlogid") == null) {
      navigate("/home");
    }
  });


  useEffect(() => {
    axiosInstance
      .post(`/viewPendingAppointnmentsByGD/${id}`)
      .then((res) => {
        console.log(res, "viewappointment");
        if (res.data.data != undefined) {
          setGardAppoinment(res.data.data);
        } else {
          setGardAppoinment([]);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  const handleRemoveAppoinment = (id) => {
    axiosInstance
      .post(`/removeAppointmentGDById/${id}`)
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          alert("removed");
          window.location.reload();
        } else {
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <div>
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {GardAppointment.length ? (
              GardAppointment.map((a) => {
                return (
                  <div class="col-4">
                    <div class="card">
                      {/* <img
                        src={`http://localhost:4010/${a.image.originalname}`}
                        class="card-img-top"
                        alt="..."
                        height="240px"
                      /> */}
                      <div class="card-body">
                        <h5 class="card-title">{a.userid.name}</h5>
                        <p class="card-text">{a.userid.email}</p>
                        <p class="card-text">{a.userid.contact}</p>
                        {a.time ? (
                          <div class="alert alert-primary" role="alert">
                            Booked Appoinment <hr/>Date : {a.date.slice(0,10)}<hr/><b>Time : {a.time}</b>
                          </div>
                        ) : (
                          <>
                            {" "}
                            <Link
                              to={`/ConfrimGard/${a._id}`}
                              class="btn btn-primary"
                            >
                              Approve
                            </Link>
                            <button
                              className="btn btn-danger"
                              onClick={() => {
                                handleRemoveAppoinment(a._id);
                              }}
                              style={{ marginLeft: "2rem" }}
                            >
                              Reject
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div class="col">
                <div
                  class="card"
                  style={{ width: "300px", margin: "11px auto" }}
                >
                  <div class="card-body">
                    <h5 class="card-title">No data</h5>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default GardAppointment;
