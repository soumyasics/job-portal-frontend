import React from "react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../Baseurl";

function AddDesign() {
  const id = localStorage.getItem("Gdlogid");
  const [register, setRegister] = useState({
    title: "",
    type: "",
    image: "",
    gdid: id,
    cost: "",
  });

  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("Gdlogid") == null) {
      navigate("/home");
    }
  });


 
  const changehandleSubmit = (a) => {
    if (a.target.name == "image") {
      setRegister({ ...register, image: a.target.files[0] });
    } else {
      setRegister({ ...register, [a.target.name]: a.target.value });
    }
  };

  const submitt = (b) => {
    console.log("submitted");
    b.preventDefault();
    console.log(register);
    axiosInstance
      .post("/addGDDesign", register, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((result) => {
        console.log("data entered", result);
        if (result.status == 200) {
          alert("Add Design Sucessfully...");
          // navigate("/Customer");
        } else {
          alert("Failed to Add");
        }
      })
      .catch((error) => {
        console.log("error", error);
      });
  };

  console.log(register);

  return (
    <div>

      <div class="container login_page">
        <div class="row">
          <div class="col-md-4">
            <div class="login_form1">
              <h5>CREATE DESIGN</h5>
              <div class="row user_buttons">
                {/* <div class="col-6">
                  <button type="button" class="btn user_button" id="button2">
                    Admin Login
                  </button>
                </div> */}
              </div>
              <form onSubmit={submitt}>
                <div class="user_login active" id="div1">
                  <div class="login_email_input">
                    <label for="name" class="form-label">
                      Title of design
                    </label>
                    <input
                      value={register.title}
                      onChange={changehandleSubmit}
                      type="text"
                      class="form-control"
                      name="title"
                      id=""
                      placeholder=""
                    />
                  </div>
                  <div class="login_email_input">
                    <label for="cost" class="form-label">
                      Cost in rupees
                    </label>
                    <input
                      value={register.cost}
                      onChange={changehandleSubmit}
                      type="number"
                      min="1"
                      class="form-control"
                      name="cost"
                      id=""
                      placeholder=""
                    />
                  </div>
                  <div class="login_email_input">
                    <label for="type" class="form-label">
                      Design type
                    </label>
                    <input
                      value={register.type}
                      onChange={changehandleSubmit}
                      type="text"
                      class="form-control"
                      name="type"
                      id=""
                      placeholder=""
                    />
                  </div>

                  <div class="login_email_input">
                    <label for="image" class="form-label">
                      image
                    </label>
                    <input
                      onChange={changehandleSubmit}
                      type="file"
                      class="form-control"
                      name="image"
                      id=""
                      placeholder=""
                    />
                  </div>
                  {/* <div class="login_email_input">
                    <label for="custId" class="form-label">
                    custId
                    </label>
                    <input
                   
                      value={register.custId}
                      onChange={changehandleSubmit}
                      type="number"
                      class="form-control"
                      name="custId"
                      id=""
                      placeholder=""
                    />
                  </div> */}

                  <div class="login_button">
                    <button class="btn login_button">Add Design</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="col-md-8">
            <div class="title1">
              <h4>Gardens are the result of a collaboration between art and nature</h4>
              <h5>
                “My passion for gardening may strike some as selfish, or merely
                an act of resignation in the face of overwhelming problems that
                beset the world. It is neither. I have found that each garden is
                just what Voltaire proposed in Candide: a microcosm of a just
                and beautiful society.”
              </h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
export default AddDesign;
