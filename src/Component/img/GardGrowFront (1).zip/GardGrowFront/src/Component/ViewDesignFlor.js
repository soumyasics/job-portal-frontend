import React, { useEffect, useState } from "react";
import axiosInstance from "../Baseurl";
import { Link, useNavigate } from "react-router-dom";

function ViewDesignFlor() {
  const [flor, setflor] = useState([]);

    
  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("florlogid") == null) {
      navigate("/home");
    }
  });


  useEffect(() => {
    axiosInstance
      .post(`/viewDesignByFid/${localStorage.getItem("florlogid")}`)
      .then((res) => {
        console.log(res,"viewdesignflor");
       if(res.data.data!=null){
        setflor(res.data.data);
       }
       else{
        setflor([])
       }
      })
      .catch((res) => {
        console.log(res);
      });
  }, []);
  const handleRemoveFDesign = (id) => {
    axiosInstance
      .post(`/delDesignById/${id}`)
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          alert("removed");
          window.location.reload();
        } else {
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };
 
  if (localStorage.getItem("florlogid") !=null) {
  return (
    <>
     
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {flor.length?
            flor.map((a) => {
              return (
                <div class="col">
                  <div class="card" style={{ width: "300px", margin: "11px auto" }}>
                    <img
                      src={`http://localhost:4010/${a.image.originalname}`}
                      class="card-img-top"
                      alt="..."
                      height="240px"
                    />
                    <div class="card-body">
                      <h5 class="card-title">{a.title}</h5>
                      <p class="card-text">Type: {a.type}</p>
                      <p class="card-text">Price: {a.cost}$</p>

                      <button href="#" class="btn btn-primary" onClick={()=>handleRemoveFDesign(a._id)} style={{margin:"10px 0"}}>
                        Delete
                      </button>
                     <Link to={`/EditFlor/${a._id}`} ><button href="#" class="btn btn-success"  style={{marginLeft:"10px "}}>
                        Edit 
                      </button></Link>
                    </div>
                  </div>
                </div>
              );
            }):
           
                <div class="col">
                  <div class="card" style={{ width: "300px", margin: "11px auto" }}>
                 
                    <div class="card-body">
                      <h5 class="card-title">No data</h5>
                  
                    </div>
                  </div>
                </div>
             }
          </div>
        </div>
      </div>
    </>
  );}
}

export default ViewDesignFlor;
