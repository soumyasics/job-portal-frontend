import React, { useEffect, useState } from "react";
import {useNavigate} from 'react-router-dom'
import axiosInstance from "../../Baseurl";

function ChatCus() {

  const navigate = useNavigate()

  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        navigate('/home')
      }
    });

  const [allGD, setallGD] = useState([]);
  const [allCust,setallCust] = useState([])
  const [gdid,setgdid] = useState('')
  const [msg, setmsg] = useState("");
  const [chat, setChat] = useState([]);

  const [refresh,setRefresh] = useState(false)

  useEffect(() => {
    axiosInstance
      .post("/viewGDs")
      .then((res) => {
        console.log(res);
        if (res.data.data != undefined) {
          setallGD(res.data.data);
        }
      })
      .catch((err) => {
        console.log(err);
      });

      axiosInstance.post(`/viewCustomers`)
      .then((res)=>{console.log(res)
      if(res.data.data!=undefined){
        setallCust(res.data.data)
      }
    })
      .catch((err)=>{console.log(err)})

    if (gdid != "") {
      axiosInstance
        .post(`/viewChat`)
        .then((res) => {
          console.log(res, "  msg list ");
          if (res.data.data != undefined) {
            setChat(res.data.data);
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }, [gdid,refresh]);


  const SubmitFun = (e) => {
    e.preventDefault()
    setRefresh(prevRefresh => !prevRefresh)
    
    axiosInstance
    .post(`/createChat`, {
      cid: localStorage.getItem("custlogid"),
      msg: msg,
      gdid: gdid,
      from:'cust'
    })
    .then((res) => {
      console.log(res);
      setChat('')
    })
    .catch((err) => {
      console.log(err);
    });
  };

  return (
    <div>
      <br/>
      
      <div className="container" style={{ backgroundColor: "white", minHeight: "500px", padding:"20px" }}>
        <div className="row">
          <div className="col-12">
            <div className="container" style={{ height: "400px", overflowX:"scroll", border: "2px solid black" }}>
              <div className="row">
                {chat.length
                  ? chat.map((a) => {
                    let x 
                    for (let i of allCust){
                      if(i._id==a.cid){
                        x = i.name
                      }
                    }
                      return (
                        <div className="col-12"> 
                           {x}: {a.msg}
                        </div>
                      );
                    })
                  : null}
              </div>
            </div>  
          </div>   
        </div>
      </div> 


      <div className="container" style={{ backgroundColor: "white", padding:"20px" }}>
          <form onSubmit={SubmitFun}>
              <div className="container">
              <hr/>
                <div className="row">
                  <div className="col-8">
                    <input
                      type="text"
                      placeholder="Text"
                      style={{ width: "100%" }}
                      onChange={(e) => {
                        setmsg(e.target.value);
                      }}
                    />
                  </div>
                  <div className="col-4">
                    <button className="btn btn-primary">Send</button>
                  </div>
                </div>
              </div>
            </form>
        </div>
        
    </div>
  );
}

export default ChatCus;
