import React, { useEffect, useState } from "react";

import axiosInstance from "../../Baseurl";
import { useNavigate } from "react-router-dom";

function ChatGuide() {
  const [gdid, setgdid] = useState("");
  const [msg, setmsg] = useState("");
  const [chat, setChat] = useState([]);

  const [refresh, setRefresh] = useState(false);

  
  const navigate = useNavigate()

  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        navigate('/home')
      }
    });


  useEffect(() => {
    axiosInstance
      .post(`/viewChat`)
      .then((res) => {
        console.log(res, "  msg list ");
        if (res.data.data != undefined) {
          setChat(res.data.data);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, [gdid, refresh]);

  const SubmitFun = (e) => {
    e.preventDefault()
    setRefresh((prevRefresh) => !prevRefresh);

    axiosInstance
      .post(`/createChat`, {
        cid: localStorage.getItem("custlogid"),
        msg: msg,
        from: "cust",
        to: "guide",
      })
      .then((res) => {
        console.log(res);
        setChat('')

      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div>
      <br />

      <div
        className="container"
        style={{
          backgroundColor: "white",
          minHeight: "500px",
          padding: "20px",
        }}
      >
        <div className="row">
          <div className="col-12">
            <div
              className="container"
              style={{
                height: "400px",
                overflowX: "scroll",
                border: "2px solid black",
              }}
            >
              <div className="row">
                {chat.length
                  ? chat.map((a) => {
                    let x 
                     if(a.cid._id==localStorage.getItem('custlogid') && (a.to=="guide"||a.from=='guide')){
                      if(a.from=='guide'){
                        x=" Guide"
                      }
                      else{
                        x=a.cid.name
                      }
                      return (
                        <div className="col-12">
                          {x}: {a.msg}
                        </div>
                      );
                     }
                      
                    })
                  : null}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        className="container"
        style={{ backgroundColor: "white", padding: "20px" }}
      >
        <form onSubmit={SubmitFun}>
          <div className="container">
            <hr />
            <div className="row">
              <div className="col-8">
                <input
                  type="text"
                  placeholder="Text"
                  style={{ width: "100%" }}
                  onChange={(e) => {
                    setmsg(e.target.value);
                  }}
                />
              </div>
              <div className="col-4">
                <button className="btn btn-primary">Send</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ChatGuide;
