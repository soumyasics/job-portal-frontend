import React, { useEffect, useState } from "react";

import axiosInstance from "../../Baseurl";
import { useNavigate, useParams } from "react-router-dom";

function ChatFlor() {

  const navigate = useNavigate()

  useEffect(() => {
      if(localStorage.getItem('custlogid')==null){
        navigate('/home')
      }
    });



  const { fdid } = useParams();
  const [msg, setmsg] = useState("");
  const [chat, setChat] = useState([]);

  const [refresh, setRefresh] = useState(false);

  useEffect(() => {
    axiosInstance
      .post(`/viewChatforCustwithFlorist/${localStorage.getItem(`custlogid`)}`)
      .then((res) => {
        console.log(res, "  msg list ");
        if (res.data.data != undefined) {
          setChat(res.data.data);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, [fdid, refresh]);

  const SubmitFun = (e) => {
    e.preventDefault()
    setRefresh((prevRefresh) => !prevRefresh);

    axiosInstance
      .post(`/createChat`, {
        from: "cust",
        to: "florist",
        msg: msg,
        cid: localStorage.getItem("custlogid"),
        fid: fdid,
      })
      .then((res) => {
        console.log(res);
        setChat('')

      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div>
      <br />

      <div
        className="container"
        style={{
          backgroundColor: "white",
          minHeight: "500px",
          padding: "20px",
        }}
      >
        <h1> Flor Chat</h1>

        <div className="row">
          <div className="col-12">
            <div
              className="container"
              style={{
                height: "400px",
                overflowX: "scroll",
                border: "2px solid black",
              }}
            >
              <div className="row">
                {chat.length
                  ? chat.map((a) => {
                      let x;
                      if (a.from == "cust") {
                        x = a.cid.name;
                      }
                      else{
                        x=a.fid.name
                      }
                      if(a.fid){
                        if(a.fid._id==fdid){
                          return (
                            <div className="col-12">
                              {x}: {a.msg}
                            </div>
                          );
                        }
                      }
                    })
                  : null}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        className="container"
        style={{ backgroundColor: "white", padding: "20px" }}
      >
        <form onSubmit={SubmitFun}>
          <div className="container">
            <hr />
            <div className="row">
              <div className="col-8">
                <input
                  type="text"
                  placeholder="Text"
                  style={{ width: "100%" }}
                  onChange={(e) => {
                    setmsg(e.target.value);
                  }}
                />
              </div>
              <div className="col-4">
                <button className="btn btn-primary">Send</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ChatFlor;
