import React, { useEffect, useState } from "react";

import axiosInstance from "../../Baseurl";
import { useNavigate, useParams } from "react-router-dom";

function ChatFlortoCust() {
  const [msg, setmsg] = useState("");
  const [chat, setChat] = useState([]);

  const [cid, setcid] = useState("");

  
  const [allcust,setallcust] = useState([])
  const [cust, setcust] = useState([]);

  const [refresh, setRefresh] = useState(false);


  const navigate = useNavigate()

  useEffect(() => {
      if(localStorage.getItem('florlogid')==null){
        navigate('/home')
      }
    });



  useEffect(() => {

    axiosInstance.post(`/viewCustomers`)
    .then((res)=>{console.log(res)
    if(res.data.data!=undefined){
      setallcust(res.data.data)
    }})
    .catch((err)=>{console.log(err);})

    
    axiosInstance
      .post(`/viewChatRecepientsforFlorist/${localStorage.getItem("florlogid")}`
      )
      .then((res) => {
        console.log(res, " view all cust");
        if (res.data.data != undefined) {
          setcust(res.data.data);
        }
      })
      .catch((err) => {
        console.log(err);
      });

    axiosInstance
      .post(`/viewChatWithCustwithFloristByIds/${localStorage.getItem(`florlogid`)}`,{cid:cid})
      .then((res) => {
        console.log(res, "  msg list ");
        if (res.data.data != undefined) {
          setChat(res.data.data);
        }
      })
      .catch((err) => {
        console.log(err);
      });

     
  }, [cid, refresh]);

  const SubmitFun = (e) => {
    e.preventDefault()
    setRefresh((prevRefresh) => !prevRefresh);
    axiosInstance
      .post(`/createChat`, {
        from: "florist",
        to: "cust",
        msg: msg,
        cid: cid,
        fid: localStorage.getItem("florlogid"),
      })
      .then((res) => {
        console.log(res);
        setChat('')

      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div>
      <br />

      <div
        className="container"
        style={{
          backgroundColor: "white",
          minHeight: "500px",
          padding: "20px",
        }}
      >
        <h1> Flor Chat</h1>

        <div className="row">
          <div className="col-2">
            {cust.length
              ? cust.map((a) => {
                let x 
                for(let i of allcust){
                  if(i._id==a){
                    x = i
                  }
                }
                  return <p> <button className="btn btn-primary" onClick={()=>{setcid(x._id)}}> {x.name} </button></p>;
                })
              : null}
          </div>
          <div className="col-10">
            <div
              className="container"
              style={{
                height: "400px",
                overflowX: "scroll",
                border: "2px solid black",
              }}
            >
              <div className="row">
                {chat.length
                  ? chat.map((a) => {
                      let x;
                      if (a.from == "cust") {
                        x = a.cid.name;
                      }
                      else{
                        x=a.fid.name
                      }
                      return (
                        <div className="col-12">
                          {x} : {a.msg}
                        </div>
                      );
                    })
                  : null}
              </div>
            </div>{" "}
            <form onSubmit={SubmitFun}>
              <div className="container">
                <div className="row">
                  <div className="col-8">
                    <input
                      type="text"
                      placeholder="Text"
                      style={{ width: "100%" }}
                      onChange={(e) => {
                        setmsg(e.target.value);
                      }}
                    />
                  </div>
                  <div className="col-4">
                    <button className="btn btn-primary">Send</button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ChatFlortoCust;
