import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

function GuideNav() {
  const Navigate = useNavigate();
  useEffect(() => {
    if (localStorage.getItem("guidelogid") == null) {
      Navigate("/Home");
    }
  });
  return (
    <div>
      <div>
        <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
          <Link
            to="/GuideHome"
            class="navbar-brand d-flex align-items-center px-4 px-lg-5"
          >
            <h1 class="m-0">Gard Grow</h1>
          </Link>
          <button
            type="button"
            class="navbar-toggler me-4"
            data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
              <Link to="/GuideHome" class="nav-item nav-link">
                Home
              </Link>
              <Link to="/AddGuidePlant" class="nav-item nav-link">
                Add Plant
              </Link>
              <Link to="/AddProduc" class="nav-item nav-link">
                Add Product
              </Link>

              {/* <a href="service.html" class="nav-item nav-link">Services</a> */}
              <div class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                  Plants
                </a>
                <div class="dropdown-menu rounded-0 m-0">
                  <Link to="/ViewGuidePlant" class="dropdown-item">
                    My Plants
                  </Link>
                  <Link to="/ViewallplantGuide" class="dropdown-item">
                    View All Plants
                  </Link>
                  {/* <Link to="/FlorLogin" class="dropdown-item">Florist</Link>
                            <Link to='/Customer' class="dropdown-item">Customer</Link> */}
                  {/* <a href="404.html" class="dropdown-item">404</a> */}
                </div>
              </div>

              <Link onClick={()=>{localStorage.clear(); window.location.reload(false)}} class="nav-item nav-link">Logout</Link>

              {/* <Link to="/register" class="nav-item nav-link">Register</Link> */}
            </div>
            <Link
              to="/ChatGuidetoCust"
              class="btn btn-primary py-4 px-lg-4 rounded-0 d-none d-lg-block"
            >
              Chat<i class="fa fa-arrow-right ms-3"></i>
            </Link>
          </div>
        </nav>
      </div>
    </div>
  );
}

export default GuideNav;
