import React from 'react'
import { Link } from 'react-router-dom'

function GDNav() {
  return (
    <div>
        <div>
         <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
        <a href="index.html" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h1 class="m-0">Gard Grow</h1>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
          
                <Link to="/" class="nav-item nav-link">Home</Link>
                <Link to="/About" class="nav-item nav-link">About</Link>
                <Link to='/GDViewProf' class="nav-item nav-link">Garden Designer Profile</Link>
                {/* <a href="service.html" class="nav-item nav-link">Services</a> */}
                <Link to="/GardAppoinment" class="nav-item nav-link">Appointments</Link>
               
                    <div class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Designs</a>
                        <div class="dropdown-menu rounded-0 m-0">
                            <Link to='/AddDesign' class="dropdown-item">Create Design</Link>
                            <Link to='/ViewDesign' class="dropdown-item">View Design</Link>
                            {/* <Link to="/FlorLogin" class="dropdown-item">Florist</Link>
                            <Link to='/Customer' class="dropdown-item">Customer</Link> */}
                            {/* <a href="404.html" class="dropdown-item">404</a> */}
                          
                        </div> 
                       
                    </div>
                    <Link onClick={()=>{localStorage.clear(); window.location.reload(false)}} class="nav-item nav-link">Logout</Link>
                    <Link to={`/ChatGDtoCust`} class="nav-item nav-link" >Chat</Link>

            </div>
        </div>
    </nav>
    </div> 
    </div>
  )
}

export default GDNav