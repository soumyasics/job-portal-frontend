import React from 'react'
import NavNoLog from './Nav'
import FlorNav from './FlorNav'
import GDNav from './GDNav'
import CustNav from './CustNav'
import GuideNav from './GuideNav'
import AdminNav from './AdminNav'

function Navbar({auth}) {
 
    if(auth==0){
        return <NavNoLog/>
    }
    else if(auth==1){
        return <CustNav/>
    }
    else if(auth==2){
        return <FlorNav/>
    }
    else if(auth==3){
        return <GDNav/>
    }
    else if(auth==4){
        return <GuideNav/>
    }
    else if(auth==5){
        return <AdminNav/>
    }
}

export default Navbar