import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

function CustNav() {
  const Navigate = useNavigate();
  useEffect(() => {
    if (localStorage.getItem("custlogid") == null) {
      Navigate("/Home");
    }
  });
  return (
    <div>
      <div>
        <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
          <Link
            to="/custhome"
            class="navbar-brand d-flex align-items-center px-4 px-lg-5"
          >
            <h1 class="m-0">Gard Grow</h1>
          </Link>
          <button
            type="button"
            class="navbar-toggler me-4"
            data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
              <Link to="/CustHome" class="nav-item nav-link">
                Home
              </Link>
              <div class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                  Plants
                </a>
                <div class="dropdown-menu rounded-0 m-0">
                  <Link to="/AddCustPlant" class="dropdown-item">
                    Add Plant
                  </Link>
                  <Link to="/ViewMyPlants" class="dropdown-item">
                    View My Plants
                  </Link>
                  <Link to="/ReceivedPlantOrders" class="dropdown-item">
                    View Received Orders 
                  </Link>
                  <Link to={`/Wishlist`} class="dropdown-item">
                    Wishlist
                  </Link>
                </div>
              </div>

              <Link to="/CustExploView" class="nav-item nav-link">
                Explore
              </Link>
              <div class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                  Customer
                </a>
                <div class="dropdown-menu rounded-0 m-0">
                  <Link to="/CustViewProf" class="dropdown-item">
                    Customer Profile
                  </Link>
                  <Link to="/ViewMyGDDesOrder" class="dropdown-item">
                    {" "}
                    Garder Design Appointment Status
                  </Link>
                  <Link to="/ViewMyFlorDesOrder" class="dropdown-item">
                    {" "}
                    Florist Design Appointment Status
                  </Link>
                  <Link to="/ViewMyProductOrders" class="dropdown-item">
                    {" "}
                    Product Order Status
                  </Link>
                  <Link to="/ViewMyPlantOrders" class="dropdown-item">
                    {" "}
                    Plant Order Status
                  </Link>
                </div>
              </div>
              {/* <Link to="/register" class="nav-item nav-link">Register</Link> */}
              <Link
                onClick={() => {
                  localStorage.clear();
                  window.location.reload(false);
                }}
                class="nav-item nav-link"
              >
                Logout
              </Link>
            </div>
           
          </div>
        </nav>
      </div>
    </div>
  );
}

export default CustNav;
