import React from "react";
import { Link } from "react-router-dom";

function AdminNav() {
  return (
    <div>
      <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
        <a
          href="index.html"
          class="navbar-brand d-flex align-items-center px-4 px-lg-5"
        >
          <h1 class="m-0">Gardener</h1>
        </a>
        <button
          type="button"
          class="navbar-toggler me-4"
          data-bs-toggle="collapse"
          data-bs-target="#navbarCollapse"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <div class="navbar-nav ms-auto p-4 p-lg-0">
            <Link to="/AdminHome" class="nav-item nav-link">
              Home
            </Link> 
            <Link to="/AdminAbout" class="nav-item nav-link">
              About
            </Link>

            {/* <a href="service.html" class="nav-item nav-link">Services</a> */}

            <div cclass="nav-item nav-link">
            <Link onClick={()=>{localStorage.clear(); window.location.reload(false)}} class="nav-item nav-link">Logout</Link>

            </div>
          </div>
          <a
            href=""
            class="btn btn-primary py-4 px-lg-4 rounded-0 d-none d-lg-block"
          >
            <i class="fa fa-arrow-right ms-3"></i>
          </a>
        </div>
      </nav>
    </div>
  );
}

export default AdminNav;
