import React from 'react'
import { Link } from 'react-router-dom'

function NavNoLog() {
  return (
    <div>
         <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
        <Link to="/home" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h1 class="m-0">Gard Grow</h1>
        </Link>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
          
                <Link to="/" class="nav-item nav-link">Home</Link>
                <Link to="/About" class="nav-item nav-link">About</Link>
                {/* <a href="service.html" class="nav-item nav-link">Services</a> */}
               
                <div class="nav-item dropdown">
                        <a  class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Login</a>
                        <div class="dropdown-menu rounded-0 m-0">
                            <Link to='/GarLogin' class="dropdown-item">Garden Designer</Link>
                            <Link to="/FlorLogin" class="dropdown-item">Florist</Link>
                            <Link to='/Customer' class="dropdown-item">Customer</Link>
                            <Link to='/Guide' class="dropdown-item">Guide</Link>
                            {/* <a href="404.html" class="dropdown-item">404</a> */}
                        </div> 
                       
                    </div>
                {/* <Link to="/Contact" class="nav-item nav-link">Contact</Link> */}
                <Link to="/About" class="nav-item nav-link"> </Link>
                <Link to="/About" class="nav-item nav-link"></Link>


            </div>
        </div>
    </nav>
    </div>
  )
}

export default NavNoLog