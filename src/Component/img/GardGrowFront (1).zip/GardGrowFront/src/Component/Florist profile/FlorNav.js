import React, { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

function FlorNav() {
  const Navigate = useNavigate();
  useEffect(() => {
    if (localStorage.getItem("florlogid") == null) {
      Navigate("/Home");
    }
  });
  
  return (
    <div>
      <div>
        <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0">
          <a
            href="index.html"
            class="navbar-brand d-flex align-items-center px-4 px-lg-5"
          >
            <h1 class="m-0">Gard Grow</h1>
          </a>
          <button
            type="button"
            class="navbar-toggler me-4"
            data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
              <Link to="/FlorHome" class="nav-item nav-link">
                Home
              </Link>
              <Link to="/FlorAbout" class="nav-item nav-link">
                About
              </Link>
              <Link to="/FlorViewProf" class="nav-item nav-link">
                Florist Profile
              </Link>
              <Link to="/FlorAppointment" class="nav-item nav-link">
                Appoinments
              </Link>

              <div class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                  Design
                </a>
                <div class="dropdown-menu rounded-0 m-0">
                  <Link to="/AddDesignFlor" class="dropdown-item">
                    Create Design
                  </Link>
                  <Link to="/ViewDesignFlor" class="dropdown-item">
                    View Design
                  </Link>
                </div>
              </div>

              <Link
                onClick={() => {
                  localStorage.clear();
                }}
                class="nav-item nav-link"
              >
                Logout
              </Link>
            </div>
            <a
              href=""
              class="btn btn-primary py-4 px-lg-4 rounded-0 d-none d-lg-block"
            >
              Get Feedback<i class="fa fa-arrow-right ms-3"></i>
            </a>
          </div>
        </nav>
      </div>
    </div>
  );
}

export default FlorNav;
