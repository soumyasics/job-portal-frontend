import React from 'react'
import FlorCaraosuel from '../FlorCarousel'
function FlorHome() {
  return (
    <div>
         <FlorCaraosuel/>
    </div>
  )
}

export default FlorHome