import React, { useEffect } from "react";
import { useState } from "react";
import axiosInstance from "../../Baseurl";
import { useNavigate, useParams } from "react-router-dom";

function ConfrimFlor() {
  const { id } = useParams();
  const [confrmapp, setconfrapp] = useState({
    date: "",
    time: "",
  });

  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("florlogid") == null) {
      navigate("/home");
    }
  });

  
  const changehandleSubmit = (a) => {
    setconfrapp({ ...confrmapp, [a.target.name]: a.target.value });
  };
  const submitt = (b) => {
    console.log("submitted");
    b.preventDefault();
    console.log(confrmapp);
    console.log('id',id);
    axiosInstance
      .post(`/ConfrimAppointmentByFlorist/${id}`, confrmapp)
      .then((result) => {
        console.log("data entered", result);
        if (result.status == 200) {
          alert("Confirm Sucessfully...");
          // navigate("/Customer");
        } else {
          alert("Failed to Confirm");
        }
      })
      .catch((error) => {
        console.log("error", error);
      });
  };
  return (
    <div>
      <div class="container login_page">
        <div class="row">
          <div class="col-md-4">
            <div class="login_form1">
              <h5>Confirm Appointment</h5>
              <div class="row user_buttons">
                {/* <div class="col-6">
                  <button type="button" class="btn user_button" id="button2">
                    Admin Login
                  </button>
                </div> */}
              </div>
              <form onSubmit={submitt}>
                <div class="user_login active" id="div1">
                  <div class="login_email_input">
                    <label for="Date" class="form-label">
                      Date
                    </label>
                    <input
                      value={confrmapp.date}
                      onChange={changehandleSubmit}
                      type="date"
                      name="date"
                      min={new Date().toISOString().split('T')[0]}
                      class="form-control"
                    />
                  </div>
                  <div class="login_email_input">
                    <label for="time" class="form-label">
                      Time
                    </label>
                    <input
                      value={confrmapp.time}
                      onChange={changehandleSubmit}
                      type="time"
                      name="time"
                      class="form-control"
                     
                    />
                  </div>

                  <div class="login_button">
                    <button class="btn login_button">Confirm</button>
                  </div>
                 
                </div>
              </form>
            </div>
          </div>
          <div class="col-md-8">
            <div class="title1">
              <h4>
                Gardens are the result of a collaboration between art and nature
              </h4>
              <h5>
                “My passion for gardening may strike some as selfish, or merely
                an act of resignation in the face of overwhelming problems that
                beset the world. It is neither. I have found that each garden is
                just what Voltaire proposed in Candide: a microcosm of a just
                and beautiful society.”
              </h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ConfrimFlor;
