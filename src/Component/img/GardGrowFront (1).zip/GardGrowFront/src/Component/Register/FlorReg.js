import React from 'react';
import { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '../../Baseurl';

function FlorRegister() {
  const [register, setRegister] = useState({
    name: '',
    city: '',
    contact: '',
    email: '',
    password: '',
    district: '',
    age: '',
    pincode: ''
  });
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  const changehandleSubmit = (a) => {
    setRegister({ ...register, [a.target.name]: a.target.value });
    if (a.target.name === 'password' && /^[a-zA-Z]+$/.test(a.target.value)) {
      setErrorMessage('Password should only contain characters.');
    } else {
      setErrorMessage('');
    }
  };

  useEffect(() => {
    console.log(register);
  });

  const navigate=useNavigate();
  const submitt = (b) => {
    console.log('submitted');
    b.preventDefault();
    axiosInstance
      .post('/registerFlorist', register)
      .then((result) => {
        console.log('data entered', result);
        if (result.status == 200) {
            alert('Register Succesfully')
          navigate('/FlorLogin')
        }
        else{
            alert('Register Failed...')
        }
      })
      .catch((error) => {
        console.log('error', error);
      });
  };

  return (
    <div>
       
      <>

        <div class="container login_page">
          <div class="row">
            <div class="col-md-4">
              <div class="login_form1">
                <h5> Florist Register</h5>
                <div class="row user_buttons">
                 
                  {/* <div class="col-6">
                    <button type="button" class="btn user_button" id="button2">
                      Admin Login
                    </button>
                  </div> */}
                </div>
                <form onSubmit={submitt}>
                  <div class="user_login active" id="div1">
                    <div class="login_email_input">
                      <label for="name" class="form-label">
                        Name
                      </label>
                      <input
                        value={register.name}
                        onChange={changehandleSubmit}
                        type="text"
                        class="form-control"
                        name="name"
                   
                        placeholder=""
                      />
                    </div>
                    <div class="login_email_input">
                      <label for="email" class="form-label">
                       Email
                      </label>
                      <input
                        value={register.email}
                        onChange={changehandleSubmit}
                        type="email"
                        class="form-control"
                        name="email"
                     
                        placeholder=""
                      />
                    </div>
                    <div class="login_email_input">
                      <label for="age" class="form-label">
                        Age
                      </label>
                      <input
                        pattern="[0-9]*"
                        value={register.age}
                        onChange={changehandleSubmit}
                        type="number"
                        class="form-control"
                        name="age"
                 
                        placeholder=""
                      />
                    </div>
                    <div class="login_email_input">
                      <label for="city" class="form-label">
                        City
                      </label>
                      <input
                        value={register.city}
                        onChange={changehandleSubmit}
                        type="text"
                        class="form-control"
                        name="city"
               
                        placeholder=""
                      />
                    </div>
                    <div class="login_email_input">
                      <label for="district" class="form-label">
                        District
                      </label>
                      <input
                        value={register.district}
                        onChange={changehandleSubmit}
                        type="text"
                        class="form-control"
                        name="district"
                   
                        placeholder=""
                      />
                    </div>
                    <div class="login_email_input">
                      <label for="contact" class="form-label">
                        Contact
                      </label>
                      <input
                        pattern="[0-9]*"
                        value={register.contact}
                        onChange={changehandleSubmit}
                        type="number"
                        class="form-control"
                        name="contact"
                     
                        placeholder=""
                      />
                    </div>
                    <div class="login_email_input">
                      <label for="pincode" class="form-label">
                        Pincode
                      </label>
                      <input
                        pattern="[0-9]*"
                        value={register.pincode}
                        onChange={changehandleSubmit}
                        type="number"
                        class="form-control"
                        name="pincode"
                    
                        placeholder=""
                      />
                    </div>

                    <div class="login_password_input">
                      <label for="password" class="form-label">
                        Password
                      </label>
                      <input
                        pattern="[A-Za-z]*"
                        class="form-control"
                        name="password"
                        type={passwordVisible ? 'text' : 'password'}
                     
                        placeholder=""
                        value={register.password}
                        onChange={changehandleSubmit}
                        title="Password should only contain characters."
                      />
                      {errorMessage && <p className="error-message">{errorMessage}</p>}
                    </div>
                    <div class="forget_password">
                      <input type="checkbox" id="showPasswordCheckbox" onChange={togglePasswordVisibility} /> Show
                      Password
                      <span>
                        <a href="#">Forget Password</a>
                      </span>
                    </div>
                    <div class="login_button">
                      <button class="btn login_button">Register</button>
                    </div>
                  </div>
                </form>

                {/*  */}
              </div>
            </div>
            <div class="col-md-8">
              <div class="title1">
                <h4> On Even the Best Gardens Being a Little Bit Imperfect</h4>
                <h5>
                  “My passion for gardening may strike some as selfish, or merely an act of resignation in the face of
                  overwhelming problems that beset the world. It is neither. I have found that each garden is just what
                  Voltaire proposed in Candide: a microcosm of a just and beautiful society.”
                </h5>
              </div>
            </div>
          </div>
        </div>
      </>
    </div>
  );
}

export default FlorRegister;