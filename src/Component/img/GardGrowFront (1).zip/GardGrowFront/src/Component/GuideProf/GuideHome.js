import React from 'react'
import GuideCaraosuel from '../GuideCarousel'

function GuideHome() {
  return (
    <div>
       
          <GuideCaraosuel/>
    </div>
  )
}

export default GuideHome