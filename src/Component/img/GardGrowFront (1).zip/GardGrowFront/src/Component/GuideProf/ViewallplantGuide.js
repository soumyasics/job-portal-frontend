import React, { useEffect, useState } from "react";

import axiosInstance from "../../Baseurl";
import { useNavigate } from "react-router-dom";

function ViewPlantGuide() {
  const [flowe, setflowe] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("guidelogid") == null) {
      navigate("/home");
    }
  });

  useEffect(() => {
    axiosInstance
      .post(`/viewAllPlants`)
      .then((res) => {
        console.log(res, "viewguideplant");
        if (res.data.data) {
          setflowe(res.data.data);
        } else {
          setflowe([]);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  if (localStorage.getItem("guidelogid") != null) {
    return (
      <>
        
        <div style={{ minHeight: "300px", margin: "15px 0px" }}>
          <div class="container text-center">
            <div class="row">
              {flowe.map((a) => {
                return (
                  <div class="col-4">
                    <div
                      class="card"
                      
                    >
                      <img
                        src={`http://localhost:4010/${a.image.originalname}`}
                        class="card-img-top"
                        alt="..."
                        height="340px"
                      />
                      <div class="card-body">
                        <h5 class="card-title">{a.name}</h5>
                        <p class="card-text">Type: {a.type}</p>
                        <p class="card-text">Price: {a.cost}$</p>

                        {/* <a href="#" class="btn btn-primary">
                        Buy Flower
                      </a> */}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default ViewPlantGuide;
