import React, { useEffect, useState } from "react";
import { Navigate, useNavigate, useParams } from "react-router-dom";
import axiosInstance from "../Baseurl";

function GDEditProf() {
  const { cardid } = useParams();

  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("Gdlogid") == null) {
      navigate("/home");
    }
  });


  const [value, setValue] = useState({
    title:'',
    type:'',
    image:null,
    gdid:localStorage.getItem("Gdlogid"),
    cost:''
  });

  const id = localStorage.getItem("Gdlogid");

  useEffect(() => {
    axiosInstance
      .post(`/viewDesignById/${cardid}`)
         
      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  const changefn = (e) => {
    if (e.target.name == "image") {
      setValue({ ...value, image: e.target.files[0] });
    } else {
      setValue({ ...value, [e.target.name]: e.target.value });
    }
  };

  const updatefcn = (e) => {
    e.preventDefault();
console.log(value);
    axiosInstance
      .post(`/editDesignByGDId/${cardid}`, value,{ headers: {
        'Content-Type': 'multipart/form-data',
      }})
      .then((response) => {
        console.log(response);
        if (response.data.status == 200) {
          alert("Design Updated");
          navigate("/ViewDesign");
        } else {
          alert("Design Failed");
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };



  // useEffect(() => {
  //   console.log(value);
  // });

  return (
    <div>
      <div
        class="container rounded bg-white mt-5 mb-5"
        style={{ width: "45rem", boxShadow: "1px 1px 1px 2px grey" }}
      >
        <div class="row">
          <div class="col-md-3 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5">
              {/* <img
                      src={`http://localhost:4010/${a.image.originalname}`}
                      class="card-img-top"
                      alt="..."
                      height="240px"
            /> */}
              <span
                class="font-weight-bold"
                style={{
                  color: "black",
                  fontFamily: "cursive",
                  fontWeight: "700",
                }}
              >
                {value.name}
              </span>
              <span
                class="text-black-50"
                style={{
                  color: "brown",
                  fontFamily: "cursive",
                  fontWeight: "700",
                }}
              >
                {value.email}
              </span>
              <span> </span>
            </div>
          </div>
          <div class="col-md-5 border-right">
            <div class="p-3 py-5">
              <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="text-right">Garden Desgin Edit</h4>
              </div>
              <form onSubmit={updatefcn} style={{ width: "30rem" }}>
                <div class="row mt-2">
                  <div class="col-md-6">
                    <label class="labels">Title</label>
                    <input
                      type="text"
                      class="form-control"
                      value={value.title}
                      name="title"
                      onChange={changefn}
                    />
                  </div>
                  <div class="col-md-6">
                    <label class="labels">Cost</label>
                    <input
                      type="number"
                      name="cost"
                      class="form-control"
                      value={value.cost}
                      onChange={changefn}
                    />
                  </div>
                </div>
                <div class="row mt-3">
                  <div class="col-md-12">
                    <label class="labels">Design Type</label>
                    <input
                      type="text"
                      class="form-control"
                      value={value.type}
                      name="type"
                      onChange={changefn}
                    />
                  </div>
                  <div class="col-md-12">
                    <label class="labels"> Image</label>
                    <input
                      type="file"
                      class="form-control"
                      name="image"
                      onChange={changefn}
                    />
                  </div>

                  <button
                    type="submit"
                    class="btn btn-primary h-23 w-100 py-2"
                    style={{ marginTop: "0.8rem" }}
                  >
                    Update
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GDEditProf;
