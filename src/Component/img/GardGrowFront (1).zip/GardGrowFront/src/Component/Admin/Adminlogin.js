import React from "react";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

function Adminlogin() {
  const navigate = useNavigate();
  const [login, setLogin] = useState({
    name: "",
    password: "",
  });
  const changehandleSubmit = (a) => {
    setLogin({ ...login, [a.target.name]: a.target.value });
  };
  useEffect(() => {
    if(localStorage.getItem('adminlog')!=null){
      navigate('/adminhome')
    }
  });

  

  const submitt = (b) => {
    console.log("submitted");
    b.preventDefault();
    if (login.name == "admin" && login.password == "admin12345") {
      localStorage.setItem("adminlog", 1);
      alert("Login successfully");
      window.location.reload(false)
      navigate('/adminhome')
    }
    else{
      alert("Invalid credentials. Please try again")
    }
  };
 

  return (
    <div>

      <div>
        <div class="container login_page">
          <form onSubmit={submitt}>
            <div class="row">
              <div class="col-md-4">
                <div class="login_form">
                  <h3> Admin Login</h3>
                  <div class="row user_buttons">
                    {/* <div class="col-6">
                    <button type="button" class="btn user_button active_button" id="button1">User Login</button>
                </div> */}
                    {/* <div class="col-6">
                    <button type="button" class="btn user_button" id="button2">Admin Login</button>
                </div> */}
                  </div>
                  <div class="user_login active" id="div1">
                    <div class="login_password_input">
                      <label for="email" class="form-label">
                        UserName
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        name="name"
                        placeholder=""
                        value={login.name}
                        onChange={changehandleSubmit}
                      />
                    </div>
                    <div class="login_password_input">
                      <label for="password" class="form-label">
                        Password
                      </label>
                      <input
                        type="password"
                        class="form-control"
                        name="password"
                        placeholder=""
                        value={login.password}
                        onChange={changehandleSubmit}
                      />
                    </div>

                    <div class="login_button">
                      <button class="btn login_button">Login</button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-8">
                <div class="title">
                  <h4 style={{ color: "black" }}>Welcome... Login Here.. </h4>
                 
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Adminlogin;
