import React, { useEffect, useState } from "react";
import { Link, redirect, useNavigate } from "react-router-dom";
import axiosInstance from "../../Baseurl";

function Adminpage() {
  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("adminlog") == null) {
      navigate("/home");
    }
  });
  const [gddata, setgddata] = useState([]);
  const [flordata, setflordata] = useState([]);
  const [custdata, setcustdata] = useState([]);
  const [plants, setplants] = useState([]);

  useEffect(() => {
    axiosInstance
      .post(`/viewGDReqs`)
      .then((res) => {
        console.log(res, "viewgd");
        if (res.data.data) {
          setgddata(res.data.data);
        } else {
          setgddata([]);
        }
      })
      .catch((err) => {
        //1.viewpendingGd
        console.log(err);
      });

    axiosInstance
      .post(`/viewFloristReqs`)
      .then((res) => {
        console.log(res, "viewflorist");
        if (res.data.data) {
          setflordata(res.data.data);
        } else {
          setflordata([]);
        }
      })
      .catch((err) => {
        console.log(err);
      });

    axiosInstance
      .post(`/viewCustomers`)
      .then((res) => {
        console.log(res, "viewcus");
        if (res.data.data) {
          setcustdata(res.data.data);
        } else {
          setcustdata([]);
        }
      })
      .catch((err) => {
        console.log(err);
      });

    axiosInstance
      .post(`/viewAllPlantsAdmin`)
      .then((res) => {
        console.log(res, "flowers");

        if (res.data.data != undefined) {
          setplants(res.data.data);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  const handleRemoveGD = (id) => {
    axiosInstance
      .post(`/delGDById/${id}`)
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          alert("removed");
          window.location.reload();
        } else {
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const handleRemoveFlor = (id) => {
    axiosInstance
      .post(`/deleteFlorist/${id}`)
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          alert("removed");
          window.location.reload();
        } else {
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const handleRemoveCust = (id) => {
    axiosInstance
      .post(`/delCustomerById/${id}`)
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          alert("removed");
          window.location.reload();
        } else {
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleRemovePlant = (id)=>{
    axiosInstance
    .post(`/delPlantById/${id}`)
    .then((res) => {
      console.log(res);
      if (res.data.status == 200) {
        alert("removed");
        window.location.reload();
      } else {
      }
    })
    .catch((err) => {
      console.log(err);
    });
  }

  const approveflorfn = (id) => {
    axiosInstance.post(`/approvefloristById/${id}`).then((res) => {
      console.log(res);
      if (res.data.status == 200) {
        alert("Approved");
        window.location.reload(false);
      }
    });
  };
  const approvegdfn = (id) => {
    axiosInstance.post(`/approveGDById/${id}`).then((res) => {
      console.log(res);
      if (res.data.status == 200) {
        alert("Approved");
        window.location.reload(false);
      }
    });
  };

  const  approvePlantfn = (id)=>{
    axiosInstance.post(`/approvePlantById/${id}`).then((res) => {
      console.log(res);
      if (res.data.status == 200) {
        alert("Approved");
        window.location.reload(false);
      }
    });
  }

  if (localStorage.getItem("adminlog") == 1) {
    return (
      <div>
        <div style={{ minHeight: "200px", margin: "150px" }}>
          <h3 style={{ color: "white", textAlign: "center" }}>View All Data</h3>
          <div class="accordion accordion-flush" id="accordionFlushExample">
            <div class="accordion-item">
              <h2 class="accordion-header">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseOne"
                  aria-expanded="false"
                  aria-controls="flush-collapseOne"
                >
                  View All Customers
                </button>
              </h2>
              <div
                id="flush-collapseOne"
                class="accordion-collapse collapse"
                data-bs-parent="#accordionFlushExample"
              >
                <div class="accordion-body">
                  {/* customer map start*/}
                  <div class="container text-center">
                    <div class="row">
                      {custdata.length ? (
                        custdata.map((a) => {
                          return (
                            <div className="col">
                              <div class="card" style={{ width: "18rem;" }}>
                                <div class="card-body">
                                  <h5 class="card-title">
                                    Customer Name: {a.name}
                                  </h5>
                                  <p class="card-text">
                                    Customer Email Id: {a.email}
                                  </p>
                                  <p class="card-text">Contact: {a.contact}</p>
                                  <button
                                    onClick={() => {
                                      handleRemoveCust(a._id);
                                    }}
                                    class="btn btn-primary"
                                  >
                                    Delete Customer
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <div className="col">
                          <div class="card" style={{ width: "18rem;" }}>
                            <div class="card-body">
                              <h5 class="card-title">No Cust to display</h5>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  {/* customer map end*/}
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseTwo"
                  aria-expanded="false"
                  aria-controls="flush-collapseTwo"
                >
                  View All Garden Designers
                </button>
              </h2>
              <div
                id="flush-collapseTwo"
                class="accordion-collapse collapse"
                data-bs-parent="#accordionFlushExample"
              >
                <div class="accordion-body">
                  {/* gd map start*/}
                  <div class="container text-center">
                    <div class="row">
                      {gddata.length ? (
                        gddata.map((a) => {
                          return (
                            <div className="col">
                              <div class="card" style={{ width: "18rem;" }}>
                                <div class="card-body">
                                  <h5 class="card-title">
                                    Garden Designer Name: {a.name}
                                  </h5>
                                  <p class="card-text">Email:{a.email}</p>
                                  <p class="card-text">Contact:{a.contact}</p>

                                  {a.isactive ? (
                                    <div
                                      class="alert alert-success"
                                      role="alert"
                                    >
                                      Approved
                                    </div>
                                  ) : (
                                    <div
                                      class="alert alert-danger"
                                      role="alert"
                                    >
                                      Pending
                                    </div>
                                  )}
                                  {a.isactive ? null : (
                                    <button
                                      className="btn btn-primary"
                                      onClick={() => {
                                        approvegdfn(a._id);
                                      }}
                                    >
                                      {" "}
                                      Approve garden Designer
                                    </button>
                                  )}
                                  <hr />
                                  <button
                                    onClick={() => {
                                      handleRemoveGD(a._id);
                                    }}
                                    class="btn btn-primary"
                                  >
                                    Delete GD
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <div className="col">
                          <div class="card" style={{ width: "18rem;" }}>
                            <div class="card-body">
                              <h5 class="card-title">No GD to display</h5>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  {/* gd map end*/}
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseThree"
                  aria-expanded="false"
                  aria-controls="flush-collapseThree"
                >
                  View All Florists
                </button>
              </h2>
              <div
                id="flush-collapseThree"
                class="accordion-collapse collapse"
                data-bs-parent="#accordionFlushExample"
              >
                <div class="accordion-body">
                  {/* flor map start*/}
                  <div class="container text-center">
                    <div class="row">
                      {flordata.length ? (
                        flordata.map((a) => {
                          return (
                            <div className="col">
                              <div class="card" style={{ width: "18rem;" }}>
                                <div class="card-body">
                                  <h5 class="card-title">
                                    Florist Name: {a.name}
                                  </h5>
                                  <p class="card-text">Email:{a.email}</p>
                                  <p class="card-text">Contact:{a.contact}</p>
                                  {a.isactive ? (
                                    <div
                                      class="alert alert-success"
                                      role="alert"
                                    >
                                      Approved
                                    </div>
                                  ) : (
                                    <div
                                      class="alert alert-danger"
                                      role="alert"
                                    >
                                      Pending
                                    </div>
                                  )}
                                  {a.isactive ? null : (
                                    <button
                                      className="btn btn-primary"
                                      onClick={() => {
                                        approveflorfn(a._id);
                                      }}
                                    >
                                      {" "}
                                      Approve Florist
                                    </button>
                                  )}
                                  <hr />
                                  <button
                                    onClick={() => {
                                      handleRemoveFlor(a._id);
                                    }}
                                    class="btn btn-primary"
                                  >
                                    Delete Florist
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <div className="col">
                          <div class="card" style={{ width: "18rem;" }}>
                            <div class="card-body">
                              <h5 class="card-title">No Florist to display</h5>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  {/* flor map end*/}
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#flush-collapseFour"
                  aria-expanded="false"
                  aria-controls="flush-collapseFour"
                >
                  View All Plants
                </button>
              </h2>
              <div
                id="flush-collapseFour"
                class="accordion-collapse collapse"
                data-bs-parent="#accordionFlushExample"
              >
                <div class="accordion-body">
                  {/* flor map start*/}
                  <div class="container text-center">
                    <div class="row">
                      {plants.length ? (
                        plants.map((a) => {
                          return (
                            <div className="col">
                              <div class="card" style={{ width: "18rem;" }}>
                                <div class="card-body">
                                  <h5 class="card-title">
                                    Plant Name: {a.name}
                                  </h5>
                                  <p class="card-text">Type :{a.type}</p>
                                 {a.addedby=="guide"? <p class="card-text">Added by {a.name}</p>: <p class="card-text">Added by {a.custId.name}</p>}
                                  {a.isactive ? (
                                    <div
                                      class="alert alert-success"
                                      role="alert"
                                    >
                                      Approved
                                    </div>
                                  ) : (
                                    <div
                                      class="alert alert-danger"
                                      role="alert"
                                    >
                                      Pending
                                    </div>
                                  )}
                                  {a.isactive ? null : (
                                    <button
                                      className="btn btn-primary"
                                      onClick={() => {
                                        approvePlantfn(a._id);
                                      }}
                                    >
                                      {" "}
                                      Approve Plant
                                    </button>
                                  )}
                                  <hr />
                                  <button
                                    onClick={() => {
                                     
                                      handleRemovePlant(a._id);
                                    }}
                                    class="btn btn-primary"
                                  >
                                    Delete Plant
                                  </button>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <div className="col">
                          <div class="card" style={{ width: "18rem;" }}>
                            <div class="card-body">
                              <h5 class="card-title">No Florist to display</h5>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  {/* flor map end*/}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } else {
    return (
      <div style={{ minHeight: "400px" }}>
        <h1 style={{ textAlign: "center", position: "relative", top: "150px" }}>
          Please{" "}
          <Link style={{ fontSize: "50px" }} to="/Admin">
            log in{" "}
          </Link>
          to see admin panel{" "}
        </h1>
      </div>
    );
  }
}

export default Adminpage;
