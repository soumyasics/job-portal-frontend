import React, { useEffect, useState } from "react";
import axiosInstance from "../Baseurl";
import { useNavigate } from "react-router-dom";

function ViewPlantGuide() {
  const [gflowers, setgflowers] = useState([]);
  useEffect(() => {
    axiosInstance
      .post(`/viewAllPlants`)
      .then((res) => {
        console.log(res);
        if(res.data.data!=undefined){
          setgflowers(res.data.data);
        }
      })
      .catch((res) => {
        console.log(res);
      });
  }, []);

  
  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("guidelogid") == null) {
      navigate("/home");
    }
  });



  if (localStorage.getItem("guidelogid") != null)
    return (
      <>
      
        <div style={{ minHeight: "300px", margin: "15px 0px" }}>
          <div class="container text-center">
            <div class="row">
              {gflowers.length?gflowers.map((a) => {
                if(a.addedby=='guide'){
                  return (
                    <div class="col">
                      <div
                        class="card"
                        style={{ width: "300px", margin: "auto" }}
                      >
                        <img
                          src={`http://localhost:4010/${a.image.originalname}`}
                          class="card-img-top"
                          alt="..."
                          height="240px"
                        />
                        <div class="card-body">
                          <h5 class="card-title">{a.name}</h5>
                          <p class="card-text">Type: {a.type}</p>
                          <p class="card-text">Price: {a.cost}$</p>  
                        </div>
                      </div>
                    </div>
                  );
                }
                
              }):<div class="col-4">
              <div
                class="card"
              
              >
               
                <div class="card-body">
                  <h5 class="card-title">No Data</h5>
                  
                </div>
              </div>
            </div>}
            </div>
          </div>
        </div>
      </>
    );
}

export default ViewPlantGuide;
