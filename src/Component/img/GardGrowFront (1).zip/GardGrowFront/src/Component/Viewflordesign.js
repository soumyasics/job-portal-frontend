import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import axiosInstance from "../Baseurl";

function Viewflordesign() {
  const Navigate = useNavigate();
  const { id } = useParams();

  const [viewflor, setviewflor] = useState([]);

      
  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("custlogid") == null) {
      navigate("/home");
    }
  });



  useEffect(() => {
    axiosInstance
      .post(`/viewDesignByFid/${id}`)
      .then((res) => {
        console.log(res);
        if (res.data.data != undefined) {
          setviewflor(res.data.data);
        } else {
          setviewflor([]);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  const handleAppoinment = () => {
    console.log(id, localStorage.getItem('custlogid'));
    axiosInstance
      .post(`/addAppointmentFlorist`,{fid:id, userid:localStorage.getItem('custlogid')})
      .then((res) => {
        console.log(res);
        if (res.data.status == 200) {
          alert("Added to Appoinment");
          Navigate("/CustExploView");
          // window.location.reload()
        } else {
          alert("failed");
          // alert.warning('Employee Already Exist')
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <div>
      
      <div style={{ minHeight: "300px", margin: "15px 0px" }}>
        <div class="container text-center">
          <div class="row">
            {viewflor.length ? (
              viewflor.map((a) => {
                return (
                  <div class="col">
                    <div
                      class="card"
                      style={{ width: "300px", margin: "11px auto" }}
                    >
                      <img
                        src={`http://localhost:4010/${a.image.originalname}`}
                        class="card-img-top"
                        alt="..."
                        height="240px"
                      />
                      <div class="card-body">
                        <h5 class="card-title">{a.title}</h5>
                        <p class="card-text">Type: {a.type}</p>
                        <p class="card-text">Price: {a.cost}$</p>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div class="col">
                <div
                  class="card"
                  style={{ width: "300px", margin: "11px auto" }}
                >
                  <div class="card-body">
                    <h5 class="card-title">No data</h5>
                  </div>
                </div>
              </div>
            )}
           
          </div>
          <button
              onClick={() => {
                handleAppoinment();
              }}
              class="btn btn-primary"
            
            >
              Book an Appoinment
            </button>
        </div>
      </div>
    </div>
  );
}

export default Viewflordesign;
