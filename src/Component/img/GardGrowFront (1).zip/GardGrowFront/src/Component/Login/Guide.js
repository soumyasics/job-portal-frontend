import React, { useEffect, useState } from 'react'
import axiosInstance from '../../Baseurl';
import { Link, useNavigate } from 'react-router-dom';

function Guide() {

    const navigate = useNavigate();

    useEffect(() => {
      if (localStorage.getItem(`guidelogid`) != null) {
        navigate("/home");
      }
    });
    const [login, setLogin] = useState({
      name: "",
      password: "",
    });
    const changehandleSubmit = (a) => {
      setLogin({ ...login, [a.target.name]: a.target.value });
    };
    useEffect(() => {
      console.log(login);
    });
  
    const submitt = (b) => {
      console.log("submitted");
      b.preventDefault();
      if (login.name == "guide" && login.password == "guide12345") {
        localStorage.setItem("guidelogid", 1);
        alert("Login successfully");
        window.location.reload(false)
      }
    };
   
  return (
    <div>
         <>
        

         <div>
        <div class="container login_page">
          <form onSubmit={submitt}>
            <div class="row">
              <div class="col-md-4">
                <div class="login_form">
                  <h3> Guide Login</h3>
                  <div class="row user_buttons">
                    {/* <div class="col-6">
                    <button type="button" class="btn user_button active_button" id="button1">User Login</button>
                </div> */}
                    {/* <div class="col-6">
                    <button type="button" class="btn user_button" id="button2">Admin Login</button>
                </div> */}
                  </div>
                  <div class="user_login active" id="div1">
                    <div class="login_password_input">
                      <label for="email" class="form-label">
                        Username
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        name="name"
                        placeholder=""
                        value={login.name}
                        onChange={changehandleSubmit}
                      />
                    </div>
                    <div class="login_password_input">
                      <label for="password" class="form-label">
                        Password
                      </label>
                      <input
                        type="password"
                        class="form-control"
                        name="password"
                        placeholder=""
                        value={login.password}
                        onChange={changehandleSubmit}
                      />
                    </div>

                    <div class="login_button">
                      <button class="btn login_button">Login</button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-8">
                <div class="title">
                 
                  <h4>'Every flower Blooms  in its own Time'</h4>
                    <h5>A rose can never be a sunflower, and a sunflower can never be a rose. All flowers are beautiful in their own way, and that's like women too</h5>
                 
                </div>
              </div>
            </div>
          </form>
        </div>
        
      </div>
</>

    </div>
  )
}

export default Guide