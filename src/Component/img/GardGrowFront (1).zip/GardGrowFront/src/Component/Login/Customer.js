import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axiosInstance from "../../Baseurl";

function Customer() {
  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem(`custlogid`) != null) {
      navigate("/home");
    }
  });
  const [login, setLogin] = useState({
    email: "",
    password: "",
  });
  const changehandleSubmit = (a) => {
    setLogin({ ...login, [a.target.name]: a.target.value });
  };

  const submitt = (b) => {
    console.log("submitted");
    b.preventDefault();
    axiosInstance
      .post("/loginCustomer", login)
      .then((result) => {
        console.log("data entered", result);
        if (result.status == 200) {
          localStorage.setItem("custlogid", result.data.data._id);
          alert("login Sucessfully...");
          window.location.reload(false)
        } else {
          alert("login Failed");
        }
      })
      .catch((error) => {
        console.log("error", error);
      });
  };
  return (
    <body>
      <div class="container login_page">
        <form onSubmit={submitt}>
          <div class="row">
            <div class="col-md-4">
              <div class="login_form">
                <h3> User Login</h3>
                <div class="row user_buttons">
                  {/* <div class="col-6">
                            <button type="button" class="btn user_button active_button" id="button1">User Login</button>
                        </div> */}
                  {/* <div class="col-6">
                            <button type="button" class="btn user_button" id="button2">Admin Login</button>
                        </div> */}
                </div>
                <div class="user_login active" id="div1">
                  <div class="login_password_input">
                    <label for="email" class="form-label">
                      Email
                    </label>
                    <input
                      type="email"
                      class="form-control"
                      name="email"
                      placeholder=""
                      value={login.email}
                      onChange={changehandleSubmit}
                    />
                  </div>
                  <div class="login_password_input">
                    <label for="password" class="form-label">
                      Password
                    </label>
                    <input
                      type="password"
                      class="form-control"
                      name="password"
                      placeholder=""
                      value={login.password}
                      onChange={changehandleSubmit}
                    />
                  </div>
                  <div class="forget_password">
                    <input
                      type="checkbox"
                      id="showPasswordCheckbox"
                      onchange="togglePasswordVisibility()"
                    />{" "}
                    Show Password
                    <span>
                      <a href="#">Forget Password</a>
                    </span>
                  </div>
                  <div class="login_button">
                    <button class="btn login_button">Login</button>
                  </div>
                  <div class="reg__link">
                    <p>Don't have an Account?</p>
                    <Link to="/CustReg" class="reg">
                      Register
                    </Link>
                  </div>
                </div>

                {/* <div class="admin_login" id="div2">
                        <div class="login_email_input">
                            <label for="email" class="form-label">Admin ID</label>
                            <input type="email" class="form-control" name="email" id="" placeholder=""/>
                        </div>
                        <div class="login_password_input">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" id="" placeholder=""/>
                        </div>
                        <div class="login_button">
                            <button class="btn login_button">Login</button>
                        </div>
                    </div> */}
              </div>
            </div>
            <div class="col-md-8">
              <div class="title" style={{ position: "relative", top: "180px" }}>
                <h4 style={{ color: "white" }}>
                  'Every flower Blooms in its own Time'
                </h4>
                <h5 style={{ color: "white" }}>
                  A rose can never be a sunflower, and a sunflower can never be
                  a rose. All flowers are beautiful in their own way, and that's
                  like women too
                </h5>
              </div>
            </div>
          </div>
        </form>
      </div>
    </body>
  );
}

export default Customer;
