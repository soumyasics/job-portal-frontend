import React from "react";
import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axiosInstance from "../Baseurl";

function Appoinment() {

  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("custlogid") == null) {
      navigate("/home");
    }
  });
  const id = localStorage.getItem("custlogid");
  const gdid = useParams();
  const [register, setRegister] = useState({
    userid: id,
    fid:""
    
  });

  const changehandleSubmit = (a) => {
    setRegister({ ...register, [a.target.name]: a.target.value });
  };

  const submitt = (b) => {
    console.log("submitted");
    b.preventDefault();
    console.log(register);
    axiosInstance
      .post(`/buyProduct/${id}`, register, {})
      .then((result) => {
        console.log("data entered", result);
        if (result.status == 200) {
          alert("Buy Successfully...");
          // navigate("/Customer");
        } else {
          alert("Failed to Buy");
        }
      })
      .catch((error) => {
        console.log("error", error);
      });
  };
 

  console.log(register);

  return (
    <div>

      <div class="container login_page">
        <div class="row">
          <div class="col-md-4">
            <div class="login_form1">
              <h5>Appoinment</h5>
              <div class="row user_buttons">
                {/* <div class="col-6">
                  <button type="button" class="btn user_button" id="button2">
                    Admin Login
                  </button>
                </div> */}
              </div>
              <form onSubmit={submitt}>
                <div class="user_login active" id="div1">
                  <div class="login_email_input">
                   
                    <input
                      value={register.date}
                      onChange={changehandleSubmit}
                      type="date"
                      class="form-control"
                      name="date"
                      id=""
                      placeholder=""
                    />
                  </div>
                  <div class="login_email_input">
                    <label for="cost" class="form-label">
                      Count
                    </label>
                    <input
                      value={register.count}
                      onChange={changehandleSubmit}
                      type="number"
                      min="1"
                      class="form-control"
                      name="count"
                      id=""
                      placeholder=""
                    />
                  </div>
                  <div class="login_email_input">
                    <label for="type" class="form-label">
                      Product Price
                    </label>
                    <input
                      value={register.price}
                      onChange={changehandleSubmit}
                      type="number"
                      class="form-control"
                      min="1"
                      name="price"
                      id=""
                      placeholder=""
                    />
                  </div>

                  <div class="login_button">
                    <button class="btn login_button">Buy</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="col-md-8">
            <div class="title1">
              <h4>
                Gardens are the result of a collaboration between art and nature
              </h4>
              <h5>
                “My passion for gardening may strike some as selfish, or merely
                an act of resignation in the face of overwhelming problems that
                beset the world. It is neither. I have found that each garden is
                just what Voltaire proposed in Candide: a microcosm of a just
                and beautiful society.”
              </h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Appoinment;
