import React, { useEffect, useState } from "react";
import axiosInstance from "../Baseurl";
import { useNavigate } from "react-router-dom";

function GuideChat() {
  const [allcust, setallcust] = useState([]);
  const [custid, setcustid] = useState("");
  const [msg, setmsg] = useState("");
  const [chat, setChat] = useState([]);
  const [refresh,setRefresh] = useState(false)

  
  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("guidelogid") == null) {
      navigate("/home");
    }
  });



  useEffect(() => {
    axiosInstance
      .post("/viewCustomers")
      .then((res) => {
        console.log(res);
        if (res.data.data != undefined) {
          setallcust(res.data.data);
        }
      })
      .catch((err) => {
        console.log(err);
      });

    if (custid != "") {
      axiosInstance
        .post(`/viewChat`, {
          cid: custid,
          gid: localStorage.getItem("guidelogid"),
        })
        .then((res) => {
          console.log(res, "  msg list ");
          if (res.data.data != undefined) {
            setChat(res.data.data);
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }, [custid,refresh]);
  const SubmitFun = (e) => {
    console.log(custid, localStorage.getItem("guidelogid"));
    setRefresh(prevRefresh => !prevRefresh)
    e.preventDefault();
    if (custid != "") {
      axiosInstance
        .post(`/createChat`, {
          cid:custid ,
          msg: msg,
          gid: localStorage.getItem("guidelogid"),
          from:'guide'
        })
        .then((res) => {
          console.log(res);
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      alert("Select a customer");
    }
  };

  return (
    <div>
      
      
      <br/>
      <div
        className="container"
        style={{ backgroundColor: "white", minHeight: "500px", padding:"20px" }}
      >
        <h3>Chat Customer</h3>
        <div className="row">
          <div className="col-3">
            {allcust.length
              ? allcust.map((a) => {
                
                  return (
                    <div style={{margin:"20px"}}>
                      <button
                        className="btn btn-primary"
                        onClick={() => {
                          setcustid(a._id);
                        }}
                      >
                        {a.name}
                      </button>
                    </div>
                  );
                })
              : null}
          </div>
          <div className="col-9">
            <div
              className="container"
              style={{ height: "400px",overflowX:"scroll",border: "2px solid black" }}
            >
              <div className="row">
                {chat.length
                  ? chat.map((a) => {
                    let x 
                if(a.from=="guide"){
                  x = a.gid.name
                }else{
                  x=a.cid.name
                }
                      return (
                        <div
                          className="col-12"
                          style={{margin:"10px 0px" }}
                        >
                          {x} : {a.msg}
                          
                        </div>
                      );
                    })
                  : null}
              </div>
            </div>
            <form onSubmit={SubmitFun}>
              <div className="container">
              <hr/>

                <div className="row">
                  <div className="col-8">
                    {" "}
                    <input
                      type="text"
                      placeholder="Text"
                      style={{ width: "100%" }}
                      onChange={(e) => {
                        setmsg(e.target.value);
                      }}
                    />
                  </div>
                  <div className="col-4">
                    {" "}
                    <button className="btn btn-primary">sent</button>
                  </div>
                
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GuideChat;